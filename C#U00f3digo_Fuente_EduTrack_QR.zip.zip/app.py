# app.py completo con:
# - Login conservado
# - PIN corregido con SOPORTE_PASSWORD
# - Dashboard con diseño administrativo clásico
# - Pantalla Estudiantes y QR con diseño tipo registro de alumnos

from datetime import datetime, timedelta
from io import BytesIO
import os
import random
import re
import smtplib
from email.message import EmailMessage
from zoneinfo import ZoneInfo

import qrcode
from docx import Document
from docx.shared import Inches, Pt
from flask import Flask, request, redirect, session, send_file, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from reportlab.lib.pagesizes import letter, landscape
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.platypus import Table, TableStyle, Paragraph
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from sqlalchemy import func, text, or_


app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "edutrack_secret_2026")

DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///edutrack.db")
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

app.config["SQLALCHEMY_DATABASE_URI"] = DATABASE_URL
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

BOGOTA = ZoneInfo("America/Bogota")

APP_NAME = "EduTrack QR"
DESARROLLADOR = "Sebastián López / StudyTask"
SLOGAN = "Tecnología para una educación moderna y responsable"

INST_NOMBRE = "INSTITUCIÓN EDUCATIVA GABRIEL CORREA VÉLEZ"
INST_SEDE = "PRINCIPAL"
INST_DANE = "199999999999"
INST_NIT = "900.999.999-1"
INST_DIRECCION = "Calle 127 # 45-67, Bogotá D.C., Colombia"
INST_RESOLUCION = "Resolución institucional demo 2026"

SOPORTE_EMAIL = os.getenv("SOPORTE_EMAIL", "studytasksoporte@gmail.com")
SOPORTE_PASSWORD = os.getenv("SOPORTE_PASSWORD", "")

CARTERA_EMAIL = "carteraedutrackqr@gmail.com"
CARTERA_TELEFONO = "3126285480"
SOPORTE_TELEFONO = "3105615621"

# Código de seguridad para limpiar auditoría.
# En Render puedes definir AUDITORIA_DELETE_HASH con un hash generado por generate_password_hash.
# Si no existe, se usa este código temporal de pruebas: Auditoria2026*
AUDITORIA_DELETE_HASH = os.getenv("AUDITORIA_DELETE_HASH", generate_password_hash("Auditoria2026*"))
HORA_INICIO_ASISTENCIA = "06:00"
HORA_FIN_ASISTENCIA_DOCENTE = "07:20"
UPLOAD_DIR = os.path.join("static", "uploads", "excusas")
os.makedirs(UPLOAD_DIR, exist_ok=True)


CSS = """
<style>
:root{
--azul:#062b63;
--azul2:#0b63ce;
--azul3:#eaf2ff;
--rojo:#dc2626;
--verde:#16a34a;
--amarillo:#fbbf24;
--n:#111827;
--bg:#f5f7fb;
--s:0 18px 45px rgba(15,23,42,.12);
}
*{box-sizing:border-box}
body{margin:0;font-family:Segoe UI,Arial,sans-serif;background:var(--bg);color:var(--n)}
a{color:var(--azul2);font-weight:800}
input,select,textarea{width:100%;padding:13px;border:1px solid #d1d5db;border-radius:12px;margin:8px 0;font-size:15px;background:white}
button,.btn{background:var(--azul);color:white;border:0;border-radius:12px;padding:13px 17px;font-weight:800;text-decoration:none;display:inline-block;cursor:pointer}
.btn-red{background:var(--rojo)!important}
.btn-green{background:var(--verde)!important}
.center{display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px;background:linear-gradient(135deg,#061b3f,#0b63ce)}
.card{background:white;border-radius:24px;padding:28px;box-shadow:var(--s)}
.login-card{width:100%;max-width:440px}
.logo{width:92px;height:92px;object-fit:contain;background:white;border-radius:20px;padding:8px}
.hero-logo{background:linear-gradient(135deg,var(--azul),var(--azul2));color:white;border-radius:22px;padding:25px;text-align:center;border-bottom:6px solid var(--amarillo)}
.hero-logo h2,.hero-logo p{color:white}
.error{color:var(--rojo);font-weight:800}
.msg{padding:13px;border-radius:13px;font-weight:800;margin:12px 0}
.ok{background:#dcfce7;color:#047857}.warn{background:#fef3c7;color:#b45309}.danger{background:#fee2e2;color:#b91c1c}

.layout{display:flex;min-height:100vh;background:#d9d9d9}
.sidebar{width:230px;background:#08224b;color:white;padding:18px;border-right:5px solid #f5b400;position:sticky;top:0;height:100vh;overflow-y:auto}
.sidebar img{width:95px;height:95px;object-fit:contain;background:white;padding:4px;margin-bottom:12px}
.sidebar h2{font-size:24px;margin:4px 0}.sidebar p{color:#dbeafe;margin-top:0;font-size:13px}
.sidebar a{display:block;color:white;text-decoration:none;padding:12px 13px;border-radius:9px;margin:8px 0;background:#1d3f70;font-size:14px}
.sidebar a:hover,.sidebar .active{background:#1267d8}.brand-box{background:rgba(255,255,255,.09);border-radius:10px;padding:12px;margin-top:18px;font-size:13px}
.main{flex:1;padding:18px;overflow:auto}

.header{background:white;border-radius:18px;padding:18px 22px;box-shadow:var(--s);border-bottom:4px solid var(--amarillo);display:grid;grid-template-columns:1fr auto;gap:18px;margin-bottom:18px}
.header-info{display:flex;gap:16px;align-items:center}.header-info img{width:72px;height:72px;object-fit:contain}.header h1{margin:0;color:var(--azul);font-size:25px}.header p{margin:4px 0;color:#334155;font-size:13px}.user-badge{background:#eff6ff;color:var(--azul);padding:9px 13px;border-radius:999px;font-weight:800;display:inline-block;margin-bottom:10px;font-size:13px}

/* DISEÑO ADMINISTRATIVO CLÁSICO */
.classic-window{background:#bfbfbf;border:1px solid #555;border-radius:5px;box-shadow:inset 0 0 0 1px #e9e9e9,0 10px 28px rgba(0,0,0,.18);padding:6px;margin-bottom:16px;color:#111;font-family:Arial,sans-serif}
.classic-title{font-size:13px;background:linear-gradient(#f5f5f5,#b8b8b8);border:1px solid #8a8a8a;padding:6px 8px;margin-bottom:4px}
.classic-toolbar{height:31px;background:linear-gradient(#ececec,#c6c6c6);border:1px solid #9b9b9b;display:flex;align-items:center;gap:8px;padding:3px 8px;margin-bottom:10px}
.tool-btn{width:23px;height:23px;border:1px solid #9d9d9d;background:#e5e5e5;border-radius:2px;text-align:center;line-height:21px;font-size:12px;color:#333}
.record-box{display:inline-flex;align-items:center;gap:5px}.record-box input{width:55px;padding:4px;border-radius:0;margin:0;height:24px;font-size:12px;background:#e6e6e6}
.fieldset{border:1px solid #eee;margin:12px 18px 18px;padding:14px 18px 16px;position:relative}
.fieldset legend{font-size:12px;padding:0 8px;color:#111}.classic-grid{display:grid;grid-template-columns:120px 1fr 130px 1fr;gap:7px 10px;align-items:center}.classic-grid label{font-size:12px;text-align:right}.classic-grid input,.classic-grid select,.classic-grid textarea{border:1px solid #aaa;border-radius:0;background:#f4f4f4;height:23px;padding:3px 6px;margin:0;font-size:12px}.classic-grid textarea{height:45px;resize:vertical}.span3{grid-column:2/5}.span-all{grid-column:1/5}.classic-actions{padding:0 18px 15px;display:flex;gap:8px;flex-wrap:wrap}.classic-btn{background:#d8d8d8;color:#111;border:1px solid #777;border-radius:3px;padding:6px 12px;font-size:12px;font-weight:bold;text-decoration:none;display:inline-block}.classic-btn.primary{background:#0b63ce;color:white}.classic-btn.red{background:#cf1717;color:white}.classic-btn.green{background:#16a34a;color:white}.classic-btn.yellow{background:#ffe28a;color:#111}.classic-info{background:#eeeeee;border:1px solid #aaa;padding:8px;font-size:12px}
.dashboard-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.classic-stat-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.classic-stat{border:1px solid #777;background:#eee;padding:10px;text-align:center}.classic-stat h3{font-size:28px;margin:0;color:#111}.classic-stat p{margin:3px 0 0;font-size:12px}.classic-stat.green{background:#d9f99d}.classic-stat.yellow{background:#fef08a}.classic-stat.red{background:#fecaca}.classic-stat.blue{background:#bfdbfe}
.finance-strip{border:1px solid #333;margin:10px 0;background:#d4d4d4;font-size:14px}.finance-row{display:grid;grid-template-columns:1.7fr 1fr;border-bottom:1px solid #333}.finance-row:last-child{border-bottom:0}.finance-row div{padding:5px;border-right:1px solid #333}.finance-row div:last-child{border-right:0;text-align:right;font-weight:bold}.finance-red{background:#c90000;color:white;font-weight:bold}.finance-yellow{background:#ffd21f;font-weight:bold}.finance-soft{background:#fff1a8}

.modern-hero{background:white;border-radius:24px;border-top:5px solid #facc15;padding:28px;box-shadow:var(--s);display:flex;align-items:center;justify-content:space-between;gap:18px;margin-bottom:20px}.modern-hero h1{margin:0;color:#0f172a;font-size:30px}.modern-hero p{margin:8px 0 0;color:#334155}.modern-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.brand-card{background:linear-gradient(135deg,#0f5132,#22c55e);color:white;border-radius:24px;border-bottom:6px solid #facc15;padding:38px;box-shadow:var(--s);text-align:center}.brand-card img{width:84px;height:84px;object-fit:contain;background:white;border-radius:18px;padding:8px}.brand-card h2{font-size:26px;margin:16px 0 8px}.brand-card p{color:#e8fff2}.summary-card,.modern-card{background:white;border-radius:24px;border-top:5px solid #facc15;padding:24px;box-shadow:var(--s)}.summary-card h2,.modern-card h2{margin-top:0;color:#0f172a}.modern-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:18px}.modern-stat{background:#f8fafc;border-left:5px solid #15803d;border-radius:18px;padding:18px}.modern-stat h3{font-size:31px;margin:0;color:#0f172a}.modern-stat p{margin:6px 0 0;color:#334155;font-size:13px}.modules-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:18px;margin:18px 0}.modern-card a{color:#14532d}.client-note{background:#ecfdf5;border:1px solid #bbf7d0;border-radius:18px;padding:16px;margin-top:14px;color:#14532d;font-weight:700}
.table-card{background:white;border-radius:12px;padding:16px;box-shadow:var(--s);margin-bottom:16px}.table-card h2{color:var(--azul);margin-top:0}table{width:100%;border-collapse:collapse;margin-top:10px}th{background:var(--azul);color:white;padding:10px;font-size:12px}td{padding:8px;border-bottom:1px solid #e5e7eb;text-align:center;font-size:13px}.estado{padding:5px 9px;border-radius:999px;font-weight:800;font-size:12px}.estado-temprano{background:#dcfce7;color:#047857}.estado-tarde{background:#fef3c7;color:#b45309}.estado-no{background:#fee2e2;color:#b91c1c}.qr-img{width:76px}.danger-link{color:var(--rojo)}
.footer{margin-top:20px;text-align:center;color:#64748b;font-size:13px}.footer strong{color:var(--azul)}.portal{width:100%;max-width:460px;text-align:center}.portal #reader{max-width:330px;margin:16px auto;border-radius:18px;overflow:hidden}.carnet{width:360px;background:white;border-radius:28px;padding:24px;text-align:center;box-shadow:var(--s);border-top:8px solid var(--azul2)}.carnet-head{background:linear-gradient(135deg,var(--azul),var(--azul2));color:white;border-radius:22px;padding:18px;border-bottom:6px solid var(--amarillo)}.carnet .qr{width:180px;margin:18px auto}.print-wrap{display:flex;align-items:center;justify-content:center;min-height:100vh;background:#eaf2ff;flex-direction:column}.contact-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}.contact-card{background:white;border-radius:20px;padding:22px;box-shadow:var(--s);border-top:5px solid var(--azul2)}.contact-icon{width:50px;height:50px;border-radius:15px;background:var(--azul2);color:white;display:flex;align-items:center;justify-content:center;font-size:22px;margin-bottom:12px}.slogan-box{margin-top:25px;background:linear-gradient(135deg,var(--azul),var(--azul2));color:white;border-radius:24px;padding:26px;text-align:center}

/* ESTUDIANTES MODERNO */
.student-page{display:grid;grid-template-columns:420px 1fr;gap:18px;align-items:start}
.student-form-card,.student-list-card{background:white;border-radius:24px;padding:24px;box-shadow:var(--s);border-top:5px solid var(--azul2)}
.student-form-card h2,.student-list-card h2{margin-top:0;color:var(--azul)}
.student-section-title{font-weight:900;color:#0f172a;margin:18px 0 8px;border-left:5px solid var(--amarillo);padding-left:10px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.student-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}
.student-table-wrap{overflow:auto}
.student-table td,.student-table th{text-align:left}
.qr-mini{width:58px;border-radius:10px;background:#f8fafc;padding:4px}
.student-pill{background:#eaf2ff;color:var(--azul);padding:6px 10px;border-radius:999px;font-weight:900;font-size:12px;display:inline-block}

/* PORTAL DOCENTE MÓVIL */
.teacher-mobile{max-width:720px;margin:auto}
.teacher-card{background:white;border-radius:22px;box-shadow:var(--s);padding:18px;margin:12px 0;border-left:6px solid var(--azul2)}
.teacher-card h3{margin:0 0 8px;color:#0f172a}
.teacher-options{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.teacher-options select,.teacher-options input{margin:0}
.mobile-top{background:white;border-radius:24px;box-shadow:var(--s);padding:20px;margin-bottom:14px;border-top:5px solid var(--amarillo)}


/* PANEL NUEVO POR ROLES */
.role-layout{display:flex;min-height:100vh;background:#eef3f8}
.role-sidebar{width:270px;background:linear-gradient(180deg,#071a33,#0b2d57);color:white;padding:22px;position:sticky;top:0;height:100vh;overflow-y:auto;border-right:6px solid #facc15}
.role-sidebar img{width:86px;height:86px;object-fit:contain;background:white;border-radius:20px;padding:8px;margin-bottom:12px}
.role-sidebar h2{margin:4px 0;font-size:24px}.role-sidebar p{color:#bfdbfe;font-size:13px;line-height:1.45}
.role-sidebar a{display:flex;gap:10px;align-items:center;color:white;text-decoration:none;background:rgba(255,255,255,.08);padding:12px 14px;border-radius:14px;margin:9px 0;font-size:14px;font-weight:800}
.role-sidebar a:hover{background:#1d4ed8}.role-main{flex:1;padding:22px;overflow:auto}.role-tag{display:inline-block;background:#facc15;color:#111827;border-radius:999px;padding:7px 12px;font-weight:900;font-size:12px;margin-top:8px}
.role-hero{background:linear-gradient(135deg,#ffffff,#eff6ff);border-radius:28px;padding:26px;box-shadow:var(--s);display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:20px;border:1px solid #dbeafe}
.role-hero h1{margin:0;color:#0f172a;font-size:32px}.role-hero p{margin:8px 0 0;color:#475569}.role-cards{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:20px}.role-card{background:white;border-radius:24px;padding:20px;box-shadow:var(--s);border-left:6px solid #2563eb}.role-card.green{border-left-color:#16a34a}.role-card.yellow{border-left-color:#f59e0b}.role-card.red{border-left-color:#dc2626}.role-card.purple{border-left-color:#7c3aed}.role-card h3{margin:0;font-size:30px;color:#0f172a}.role-card p{margin:6px 0 0;color:#475569;font-weight:700}.role-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:18px}.role-panel{background:white;border-radius:24px;padding:22px;box-shadow:var(--s);border-top:5px solid #2563eb}.role-panel h2{margin-top:0;color:#0f172a}.role-panel ul{padding-left:20px;line-height:1.8}.role-muted{background:#f8fafc;border:1px dashed #cbd5e1;border-radius:18px;padding:14px;color:#475569}.blocked-box{max-width:620px;margin:80px auto;background:white;border-radius:28px;padding:32px;box-shadow:var(--s);text-align:center;border-top:6px solid #dc2626}.small-action{font-size:12px;padding:8px 10px;border-radius:10px}.top-actions{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}.audit-row td{text-align:left}.security-note{background:#ecfdf5;border:1px solid #bbf7d0;color:#14532d;border-radius:16px;padding:14px;margin:12px 0;font-weight:800}.welcome-msg{font-size:13px;color:#dbeafe;line-height:1.45;margin:10px 0 14px}.notice-box{background:#fff7ed;border:1px solid #fed7aa;color:#9a3412;border-radius:18px;padding:14px;margin:0 0 18px;font-weight:800}.filter-bar{background:white;border-radius:20px;padding:16px;box-shadow:var(--s);margin-bottom:16px}.print-card{background:white;border-radius:18px;padding:18px;box-shadow:var(--s);margin:12px 0;border-left:5px solid #2563eb}.parent-report-head{display:flex;justify-content:space-between;gap:12px;align-items:center}.parent-report-head img{width:70px;height:70px;object-fit:contain}.mini-text{font-size:12px;color:#64748b}
@media(max-width:1100px){.role-layout{flex-direction:column}.role-sidebar{width:100%;height:auto;position:relative}.role-hero,.role-grid{grid-template-columns:1fr;display:block}.role-cards{grid-template-columns:1fr 1fr}.top-actions{justify-content:flex-start}.role-main{padding:12px}}
@media(max-width:650px){.role-cards{grid-template-columns:1fr}.role-hero h1{font-size:25px}}

@media(max-width:1100px){.layout{flex-direction:column}.sidebar{width:100%;height:auto;position:relative;border-right:0;border-bottom:5px solid var(--amarillo)}.header,.dashboard-grid,.classic-grid,.contact-grid{grid-template-columns:1fr}.classic-grid label{text-align:left}.span3,.span-all{grid-column:auto}.classic-stat-grid{grid-template-columns:1fr 1fr}.student-page{grid-template-columns:1fr}.form-row{grid-template-columns:1fr}.teacher-options{grid-template-columns:1fr}.main{padding:12px}}
@media print{.no-print{display:none}.print-wrap{background:white}.carnet{box-shadow:none}}


/* HISTORIAL DE NOVEDADES Y CONVIVENCIA */
.conv-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;margin-bottom:18px}
.conv-card{background:white;border-radius:24px;padding:22px;box-shadow:var(--s);border-left:7px solid #2563eb}
.conv-card.red{border-left-color:#dc2626}.conv-card.orange{border-left-color:#f59e0b}.conv-card.green{border-left-color:#16a34a}.conv-card h2{margin:0;color:#0f172a}.conv-card p{color:#475569;font-weight:700}.novedad-badge{display:inline-block;border-radius:999px;padding:6px 10px;font-size:12px;font-weight:900}.badge-tarde{background:#fef3c7;color:#92400e}.badge-excusa{background:#dbeafe;color:#1e3a8a}.badge-salida{background:#dcfce7;color:#14532d}.badge-citacion{background:#ede9fe;color:#5b21b6}.citation-paper{background:white;border-radius:18px;padding:28px;box-shadow:var(--s);max-width:900px;margin:auto}.citation-head{display:grid;grid-template-columns:90px 1fr;gap:16px;align-items:center;border-bottom:2px solid #0b2d57;padding-bottom:12px;margin-bottom:18px}.citation-head img{width:80px;height:80px;object-fit:contain}.firma-linea{margin-top:36px;border-top:1px solid #111;width:260px;padding-top:6px;font-weight:800}.field-help{font-size:12px;color:#64748b;margin-top:-4px}
@media(max-width:900px){.conv-grid{grid-template-columns:1fr}.citation-head{grid-template-columns:1fr;text-align:center}}

</style>
"""


class Estudiante(db.Model):
    __tablename__ = "estudiantes"
    id = db.Column(db.Integer, primary_key=True)
    codigo = db.Column(db.String(80), unique=True, nullable=False)
    nombre = db.Column(db.String(120), nullable=False)
    apellido = db.Column(db.String(120), nullable=False)
    grado = db.Column(db.String(30), nullable=False)
    director = db.Column(db.String(120), nullable=False)
    documento = db.Column(db.String(80), default="")
    rh = db.Column(db.String(20), default="")
    acudiente = db.Column(db.String(160), default="")
    padre = db.Column(db.String(160), default="")
    madre = db.Column(db.String(160), default="")
    telefono_acudiente = db.Column(db.String(80), default="")
    correo_acudiente = db.Column(db.String(160), default="")
    direccion = db.Column(db.String(220), default="")
    observacion = db.Column(db.Text, default="")


class Usuario(db.Model):
    __tablename__ = "usuarios"
    id = db.Column(db.Integer, primary_key=True)
    usuario = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.Text, nullable=False)
    rol = db.Column(db.String(60), nullable=False)
    correo = db.Column(db.String(160), default="")
    grupo_docente = db.Column(db.String(30), default="")
    grados_clase = db.Column(db.String(200), default="")
    password_temporal = db.Column(db.Boolean, default=False)


class IngresoPorteria(db.Model):
    __tablename__ = "ingresos"
    id = db.Column(db.Integer, primary_key=True)
    estudiante_id = db.Column(db.Integer, db.ForeignKey("estudiantes.id"), nullable=False)
    fecha = db.Column(db.String(20), nullable=False)
    hora = db.Column(db.String(20), nullable=False)
    dia = db.Column(db.String(30), nullable=False)
    estado = db.Column(db.String(30), nullable=False)
    periodo = db.Column(db.String(30), nullable=False)
    registrado_por = db.Column(db.String(120), default="Portal móvil")
    estudiante = db.relationship("Estudiante")


class AsistenciaClase(db.Model):
    __tablename__ = "asistencias_clase"
    id = db.Column(db.Integer, primary_key=True)
    estudiante_id = db.Column(db.Integer, db.ForeignKey("estudiantes.id"), nullable=False)
    docente = db.Column(db.String(120), nullable=False)
    grupo = db.Column(db.String(30), nullable=False)
    fecha = db.Column(db.String(20), nullable=False)
    hora = db.Column(db.String(20), nullable=False)
    estado = db.Column(db.String(30), nullable=False)
    periodo = db.Column(db.String(30), nullable=False)
    observacion = db.Column(db.Text, default="")
    estudiante = db.relationship("Estudiante")


class Excusa(db.Model):
    __tablename__ = "excusas"
    id = db.Column(db.Integer, primary_key=True)
    estudiante_id = db.Column(db.Integer, db.ForeignKey("estudiantes.id"), nullable=False)
    fecha = db.Column(db.String(20), nullable=False)
    motivo = db.Column(db.Text, nullable=False)
    registrado_por = db.Column(db.String(120), nullable=False)
    periodo = db.Column(db.String(30), nullable=False)
    estudiante = db.relationship("Estudiante")


class Recuperacion(db.Model):
    __tablename__ = "recuperaciones"
    id = db.Column(db.Integer, primary_key=True)
    usuario = db.Column(db.String(80), nullable=False)
    pin = db.Column(db.String(80), nullable=False)


class Configuracion(db.Model):
    __tablename__ = "configuracion"
    id = db.Column(db.Integer, primary_key=True)
    periodo_actual = db.Column(db.String(30), default="Periodo 2")
    jornada = db.Column(db.String(30), default="Mañana")
    modo_mantenimiento = db.Column(db.Boolean, default=False)
    mensaje_mantenimiento = db.Column(db.String(255), default="Sistema en mantenimiento técnico.")


class Auditoria(db.Model):
    __tablename__ = "auditoria"
    id = db.Column(db.Integer, primary_key=True)
    fecha = db.Column(db.String(20), nullable=False)
    hora = db.Column(db.String(20), nullable=False)
    usuario = db.Column(db.String(120), default="Sistema")
    rol = db.Column(db.String(60), default="")
    accion = db.Column(db.String(120), nullable=False)
    detalle = db.Column(db.Text, default="")
    ip = db.Column(db.String(80), default="")


class Novedad(db.Model):
    __tablename__ = "novedades"
    id = db.Column(db.Integer, primary_key=True)
    estudiante_id = db.Column(db.Integer, db.ForeignKey("estudiantes.id"), nullable=False)
    tipo = db.Column(db.String(60), nullable=False)  # llegada_tarde, excusa, salida_anticipada, citacion
    motivo = db.Column(db.String(160), default="")
    observacion = db.Column(db.Text, default="")
    estado = db.Column(db.String(60), default="Abierta")
    archivo = db.Column(db.String(255), default="")
    acudiente_autoriza = db.Column(db.String(160), default="")
    fecha = db.Column(db.String(20), nullable=False)
    hora = db.Column(db.String(20), nullable=False)
    periodo = db.Column(db.String(30), default="")
    registrado_por = db.Column(db.String(120), default="")
    estudiante = db.relationship("Estudiante")


class Citacion(db.Model):
    __tablename__ = "citaciones"
    id = db.Column(db.Integer, primary_key=True)
    estudiante_id = db.Column(db.Integer, db.ForeignKey("estudiantes.id"), nullable=False)
    fecha_creacion = db.Column(db.String(20), nullable=False)
    hora_creacion = db.Column(db.String(20), nullable=False)
    fecha_citacion = db.Column(db.String(20), nullable=False)
    hora_citacion = db.Column(db.String(20), default="")
    motivo = db.Column(db.String(180), default="Llegadas tarde")
    observaciones = db.Column(db.Text, default="")
    acudiente = db.Column(db.String(160), default="")
    estado = db.Column(db.String(60), default="Generada")
    generado_por = db.Column(db.String(120), default="")
    periodo = db.Column(db.String(30), default="")
    estudiante = db.relationship("Estudiante")


def page(title, body):
    return f"""<!doctype html><html lang="es"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>EduTrack QR | {title}</title>{CSS}</head><body>{body}</body></html>"""


def footer():
    return f"""<div class="footer"><strong>{APP_NAME}</strong> © 2026 | {SLOGAN}<br>Desarrollado por <b>{DESARROLLADOR}</b></div>"""



def menu_items_por_rol():
    rol = rol_actual()
    items = [("/dashboard", "Inicio")]
    if rol in ["Soporte", "Administrador"]:
        items += [
            ("/usuarios", "Gestión de usuarios"),
            ("/configuracion", "Configuración"),
            ("/auditoria", "Auditoría"),
            ("/backup", "Backup"),
            ("/soporte", "Servidores"),
            ("/panel_convivencia", "Panel convivencia"),
            ("/historial_novedades", "Historial novedades"),
            ("/citaciones", "Citaciones"),
            ("/buscar_estudiantes", "Buscar estudiante"),
            ("/estudiantes_grupo", "Grupos de estudiantes"),
            ("/registrar_estudiante", "Registrar estudiante"),
            ("/carnes", "Carnés y QR"),
            ("/ingreso_manual", "Ingreso manual"),
            ("/importar_estudiantes", "Importar Excel"),
            ("/reportes", "Reportes"),
            ("/reportes_padres", "Reportes padres"),
        ]
    elif rol == "Rectoría":
        items += [
            ("/configuracion", "Periodo y jornada"),
            ("/buscar_estudiantes", "Buscar estudiante"),
            ("/estudiantes_grupo", "Grupos de estudiantes"),
            ("/reportes", "Reportes globales"),
            ("/reportes_padres", "Reportes padres"),
            ("/auditoria", "Auditoría"),
            ("/alertas", "Estadísticas/Alertas"),
            ("/historial_novedades", "Historial novedades"),
            ("/citaciones", "Citaciones"),
            ("/excusas", "Excusas"),
            ("/contacto", "Contacto"),
        ]
    elif rol == "Coordinación":
        items += [
            ("/panel_convivencia", "Panel convivencia"),
            ("/historial_novedades", "Historial novedades"),
            ("/citaciones", "Citaciones"),
            ("/buscar_estudiantes", "Buscar estudiante"),
            ("/estudiantes_grupo", "Grupos por filtro"),
            ("/ingreso_manual", "Ingreso manual"),
            ("/alertas", "Alertas"),
            ("/excusas", "Justificaciones"),
            ("/reportes", "Reportes por grupo"),
            ("/reportes_padres", "Reportes padres"),
            ("/portal", "Portal ingreso"),
        ]
    elif rol == "Secretaría":
        items += [
            ("/registrar_estudiante", "Registrar estudiante"),
            ("/buscar_estudiantes", "Buscar estudiante"),
            ("/estudiantes_grupo", "Lista por grado"),
            ("/carnes", "Carnés y QR"),
            ("/ingreso_manual", "Ingreso manual"),
            ("/importar_estudiantes", "Importar Excel"),
            ("/exportar_estudiantes", "Exportar Excel"),
            ("/portal", "Portal ingreso"),
            ("/contacto", "Contacto"),
        ]
    elif rol == "Docente":
        items += [("/docente-movil", "App docentes"), ("/docente", "Vista tabla")]
    return items

def shell(content):
    enlaces = ''.join(f'<a href="{url}">{nombre}</a>' for url, nombre in menu_items_por_rol())
    return f"""
<div class="role-layout">
  <aside class="role-sidebar">
    <img src="/static/img/logo-colegio.png" alt="Logo">
    <h2>BIENVENIDO SEÑOR {session.get('usuario','').upper()}</h2>
    <p class="welcome-msg">Bienvenido a {APP_NAME}, un sistema de tecnología para una educación moderna y responsable.</p>
    <span class="role-tag">{rol_actual() or 'Sin rol'}</span>
    <br><br>
    {enlaces}
    <a href="/logout">Salir</a>
    <div class="brand-box"><h3>Control por roles</h3><p>Cada usuario ve solo lo que necesita.</p></div>
  </aside>
  <main class="role-main">{content}{footer()}</main>
</div>
"""


def acceso_denegado(mensaje="No tienes permiso para acceder a este módulo."):
    return page("Acceso denegado", shell(f"""
<div class='blocked-box'>
  <h1>Acceso restringido</h1>
  <p>{mensaje}</p>
  <a class='btn' href='/dashboard'>Volver al panel</a>
</div>
"""))


def ahora(): return datetime.now(BOGOTA)
def fecha_hoy(): return ahora().strftime("%Y-%m-%d")
def hora_actual(): return ahora().strftime("%H:%M:%S")
def fecha_linda(): return ahora().strftime("%d/%m/%Y")


def es_hash_password(valor):
    valor = valor or ""
    return valor.startswith("scrypt:") or valor.startswith("pbkdf2:")


def crear_hash(password):
    return generate_password_hash(password or "")


def verificar_password(password_guardada, password_ingresada):
    if es_hash_password(password_guardada):
        return check_password_hash(password_guardada, password_ingresada or "")
    return (password_guardada or "").strip() == (password_ingresada or "").strip()


def migrar_columnas():
    comandos_postgres = [
        "ALTER TABLE citaciones ADD COLUMN IF NOT EXISTS fecha_creacion VARCHAR(20) DEFAULT ''",
        "ALTER TABLE citaciones ADD COLUMN IF NOT EXISTS hora_creacion VARCHAR(20) DEFAULT ''",
        "ALTER TABLE citaciones ADD COLUMN IF NOT EXISTS estado VARCHAR(40) DEFAULT 'Abierta'",
        "ALTER TABLE citaciones ADD COLUMN IF NOT EXISTS generado_por VARCHAR(120) DEFAULT ''",
        "ALTER TABLE citaciones ADD COLUMN IF NOT EXISTS periodo VARCHAR(30) DEFAULT 'Periodo 2'",
        "ALTER TABLE usuarios ALTER COLUMN password TYPE TEXT",
        "ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS correo VARCHAR(160) DEFAULT ''",
        "ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS grupo_docente VARCHAR(30) DEFAULT ''",
        "ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS grados_clase VARCHAR(200) DEFAULT ''",
        "ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS password_temporal BOOLEAN DEFAULT FALSE",
        "ALTER TABLE ingresos ADD COLUMN IF NOT EXISTS registrado_por VARCHAR(120) DEFAULT 'Portal móvil'",
        "ALTER TABLE configuracion ADD COLUMN IF NOT EXISTS periodo_actual VARCHAR(30) DEFAULT 'Periodo 2'",
        "ALTER TABLE configuracion ADD COLUMN IF NOT EXISTS jornada VARCHAR(30) DEFAULT 'Mañana'",
        "ALTER TABLE configuracion ADD COLUMN IF NOT EXISTS modo_mantenimiento BOOLEAN DEFAULT FALSE",
        "ALTER TABLE configuracion ADD COLUMN IF NOT EXISTS mensaje_mantenimiento VARCHAR(255) DEFAULT 'Sistema en mantenimiento técnico.'",
        "ALTER TABLE estudiantes ADD COLUMN IF NOT EXISTS documento VARCHAR(80) DEFAULT ''",
        "ALTER TABLE estudiantes ADD COLUMN IF NOT EXISTS rh VARCHAR(20) DEFAULT ''",
        "ALTER TABLE estudiantes ADD COLUMN IF NOT EXISTS acudiente VARCHAR(160) DEFAULT ''",
        "ALTER TABLE estudiantes ADD COLUMN IF NOT EXISTS padre VARCHAR(160) DEFAULT ''",
        "ALTER TABLE estudiantes ADD COLUMN IF NOT EXISTS madre VARCHAR(160) DEFAULT ''",
        "ALTER TABLE estudiantes ADD COLUMN IF NOT EXISTS telefono_acudiente VARCHAR(80) DEFAULT ''",
        "ALTER TABLE estudiantes ADD COLUMN IF NOT EXISTS correo_acudiente VARCHAR(160) DEFAULT ''",
        "ALTER TABLE estudiantes ADD COLUMN IF NOT EXISTS direccion VARCHAR(220) DEFAULT ''",
        "ALTER TABLE estudiantes ADD COLUMN IF NOT EXISTS observacion TEXT DEFAULT ''",
        "ALTER TABLE novedades ADD COLUMN IF NOT EXISTS motivo VARCHAR(160) DEFAULT ''",
        "ALTER TABLE novedades ADD COLUMN IF NOT EXISTS observacion TEXT DEFAULT ''",
        "ALTER TABLE novedades ADD COLUMN IF NOT EXISTS estado VARCHAR(60) DEFAULT 'Abierta'",
        "ALTER TABLE novedades ADD COLUMN IF NOT EXISTS archivo VARCHAR(255) DEFAULT ''",
        "ALTER TABLE novedades ADD COLUMN IF NOT EXISTS acudiente_autoriza VARCHAR(160) DEFAULT ''",
        "ALTER TABLE novedades ADD COLUMN IF NOT EXISTS periodo VARCHAR(30) DEFAULT ''",
        "ALTER TABLE novedades ADD COLUMN IF NOT EXISTS registrado_por VARCHAR(120) DEFAULT ''",
        "ALTER TABLE citaciones ADD COLUMN IF NOT EXISTS hora_citacion VARCHAR(20) DEFAULT ''",
        "ALTER TABLE citaciones ADD COLUMN IF NOT EXISTS observaciones TEXT DEFAULT ''",
        "ALTER TABLE citaciones ADD COLUMN IF NOT EXISTS acudiente VARCHAR(160) DEFAULT ''",
        "ALTER TABLE citaciones ADD COLUMN IF NOT EXISTS estado VARCHAR(60) DEFAULT 'Generada'",
        "ALTER TABLE citaciones ADD COLUMN IF NOT EXISTS generado_por VARCHAR(120) DEFAULT ''",
        "ALTER TABLE citaciones ADD COLUMN IF NOT EXISTS periodo VARCHAR(30) DEFAULT ''"
    ]
    comandos_sqlite = [
        ("usuarios", "correo", "ALTER TABLE usuarios ADD COLUMN correo VARCHAR(160) DEFAULT ''"),
        ("usuarios", "grupo_docente", "ALTER TABLE usuarios ADD COLUMN grupo_docente VARCHAR(30) DEFAULT ''"),
        ("usuarios", "grados_clase", "ALTER TABLE usuarios ADD COLUMN grados_clase VARCHAR(200) DEFAULT ''"),
        ("usuarios", "password_temporal", "ALTER TABLE usuarios ADD COLUMN password_temporal BOOLEAN DEFAULT 0"),
        ("ingresos", "registrado_por", "ALTER TABLE ingresos ADD COLUMN registrado_por VARCHAR(120) DEFAULT 'Portal móvil'"),
        ("configuracion", "periodo_actual", "ALTER TABLE configuracion ADD COLUMN periodo_actual VARCHAR(30) DEFAULT 'Periodo 2'"),
        ("configuracion", "jornada", "ALTER TABLE configuracion ADD COLUMN jornada VARCHAR(30) DEFAULT 'Mañana'"),
        ("configuracion", "modo_mantenimiento", "ALTER TABLE configuracion ADD COLUMN modo_mantenimiento BOOLEAN DEFAULT 0"),
        ("configuracion", "mensaje_mantenimiento", "ALTER TABLE configuracion ADD COLUMN mensaje_mantenimiento VARCHAR(255) DEFAULT 'Sistema en mantenimiento técnico.'"),
        ("estudiantes", "documento", "ALTER TABLE estudiantes ADD COLUMN documento VARCHAR(80) DEFAULT ''"),
        ("estudiantes", "rh", "ALTER TABLE estudiantes ADD COLUMN rh VARCHAR(20) DEFAULT ''"),
        ("estudiantes", "acudiente", "ALTER TABLE estudiantes ADD COLUMN acudiente VARCHAR(160) DEFAULT ''"),
        ("estudiantes", "padre", "ALTER TABLE estudiantes ADD COLUMN padre VARCHAR(160) DEFAULT ''"),
        ("estudiantes", "madre", "ALTER TABLE estudiantes ADD COLUMN madre VARCHAR(160) DEFAULT ''"),
        ("estudiantes", "telefono_acudiente", "ALTER TABLE estudiantes ADD COLUMN telefono_acudiente VARCHAR(80) DEFAULT ''"),
        ("estudiantes", "correo_acudiente", "ALTER TABLE estudiantes ADD COLUMN correo_acudiente VARCHAR(160) DEFAULT ''"),
        ("estudiantes", "direccion", "ALTER TABLE estudiantes ADD COLUMN direccion VARCHAR(220) DEFAULT ''"),
        ("estudiantes", "observacion", "ALTER TABLE estudiantes ADD COLUMN observacion TEXT DEFAULT ''"),
        ("novedades", "motivo", "ALTER TABLE novedades ADD COLUMN motivo VARCHAR(160) DEFAULT ''"),
        ("novedades", "observacion", "ALTER TABLE novedades ADD COLUMN observacion TEXT DEFAULT ''"),
        ("novedades", "estado", "ALTER TABLE novedades ADD COLUMN estado VARCHAR(60) DEFAULT 'Abierta'"),
        ("novedades", "archivo", "ALTER TABLE novedades ADD COLUMN archivo VARCHAR(255) DEFAULT ''"),
        ("novedades", "acudiente_autoriza", "ALTER TABLE novedades ADD COLUMN acudiente_autoriza VARCHAR(160) DEFAULT ''"),
        ("novedades", "periodo", "ALTER TABLE novedades ADD COLUMN periodo VARCHAR(30) DEFAULT ''"),
        ("novedades", "registrado_por", "ALTER TABLE novedades ADD COLUMN registrado_por VARCHAR(120) DEFAULT ''"),
        ("citaciones", "hora_citacion", "ALTER TABLE citaciones ADD COLUMN hora_citacion VARCHAR(20) DEFAULT ''"),
        ("citaciones", "observaciones", "ALTER TABLE citaciones ADD COLUMN observaciones TEXT DEFAULT ''"),
        ("citaciones", "acudiente", "ALTER TABLE citaciones ADD COLUMN acudiente VARCHAR(160) DEFAULT ''"),
        ("citaciones", "estado", "ALTER TABLE citaciones ADD COLUMN estado VARCHAR(60) DEFAULT 'Generada'"),
        ("citaciones", "generado_por", "ALTER TABLE citaciones ADD COLUMN generado_por VARCHAR(120) DEFAULT ''"),
        ("citaciones", "periodo", "ALTER TABLE citaciones ADD COLUMN periodo VARCHAR(30) DEFAULT ''")
    ]
    try:
        if "postgresql" in DATABASE_URL:
            for c in comandos_postgres:
                try: db.session.execute(text(c))
                except Exception: db.session.rollback()
        else:
            for tabla, columna, comando in comandos_sqlite:
                try:
                    cols = [r[1] for r in db.session.execute(text(f"PRAGMA table_info({tabla})")).fetchall()]
                    if columna not in cols: db.session.execute(text(comando))
                except Exception: db.session.rollback()
        db.session.commit()
    except Exception as e:
        print("MIGRACION:", e); db.session.rollback()


def registrar_auditoria(accion, detalle=""):
    try:
        db.session.add(Auditoria(fecha=fecha_hoy(), hora=hora_actual(), usuario=session.get("usuario", "Sistema"), rol=session.get("rol", ""), accion=accion, detalle=str(detalle)[:1000], ip=request.headers.get("X-Forwarded-For", request.remote_addr or "")))
        db.session.commit()
    except Exception as e:
        print("AUDITORIA:", e); db.session.rollback()


def inicializar_bd():
    db.create_all(); migrar_columnas()
    if not Configuracion.query.first(): db.session.add(Configuracion(periodo_actual="Periodo 2", jornada="Mañana"))
    base = [
        ("admin","1234","Administrador","studytasksoporte@gmail.com","",""),
        ("soporte","1234","Soporte","studytasksoporte@gmail.com","",""),
        ("rectoria","1234","Rectoría","","",""),
        ("coordinacion","1234","Coordinación","","",""),
        ("secretaria","1234","Secretaría","","",""),
        ("docente","1234","Docente","","10","8,9,10,11")
    ]
    for usuario,password,rol,correo,grupo,grados_clase in base:
        u = Usuario.query.filter(func.lower(Usuario.usuario) == usuario.lower()).first()
        if not u:
            db.session.add(Usuario(usuario=usuario,password=crear_hash(password),rol=rol,correo=correo,grupo_docente=grupo,grados_clase=grados_clase,password_temporal=True))
        else:
            if not es_hash_password(u.password): u.password = crear_hash(u.password)
            if not u.correo and correo: u.correo = correo
            if not u.grupo_docente and grupo: u.grupo_docente = grupo
            if not getattr(u, "grados_clase", "") and grados_clase: u.grados_clase = grados_clase
            if u.usuario in ["admin"] and u.rol == "Rectoría": u.rol = "Administrador"
    db.session.commit()


def ruta_publica():
    return request.path.startswith("/static") or request.path in ["/", "/login", "/logout", "/recuperar", "/validar_pin", "/legal", "/cookies", "/contacto", "/portal"] or request.path.startswith("/qr/")


@app.before_request
def before():
    inicializar_bd()
    if requiere_login():
        ultimo = session.get("ultimo_movimiento")
        ahora_ts = ahora().timestamp()
        if ultimo and ahora_ts - float(ultimo) > 600:
            session.clear()
            return redirect("/login")
        session["ultimo_movimiento"] = ahora_ts
        if session.get("password_temporal") and request.path not in ["/cambiar_password", "/logout"] and not request.path.startswith("/static"):
            return redirect("/cambiar_password")
    try:
        cfg = Configuracion.query.first()
        if cfg and cfg.modo_mantenimiento and requiere_login() and rol_actual() not in ["Soporte", "Administrador"] and not ruta_publica():
            return page("Mantenimiento", f"<div class='center'><section class='card login-card'><h1>Sistema en mantenimiento</h1><p>{cfg.mensaje_mantenimiento}</p><a class='btn' href='/logout'>Salir</a></section></div>")
    except Exception:
        pass

def config():
    c = Configuracion.query.first()
    if not c:
        c = Configuracion(periodo_actual="Periodo 2", jornada="Mañana")
        db.session.add(c); db.session.commit()
    return c


def periodo_actual(): return config().periodo_actual or "Periodo 2"
def jornada_actual(): return config().jornada or "Mañana"


def grados_disponibles():
    return sorted({e.grado for e in Estudiante.query.all()}, key=lambda x: int(str(x).split("-")[0]) if str(x).split("-")[0].isdigit() else 999)


def normalizar_lista_grados(texto):
    partes = re.split(r"[,;\s]+", texto or "")
    return [p.strip().replace("°", "") for p in partes if p.strip()]


def grados_docente_autorizados():
    if rol_actual() != "Docente":
        return grados_disponibles()
    u = Usuario.query.filter_by(usuario=session.get("usuario")).first()
    permitidos = []
    if u:
        if u.grupo_docente:
            permitidos.append(str(u.grupo_docente).strip())
        permitidos += normalizar_lista_grados(getattr(u, "grados_clase", ""))
    permitidos = sorted(set([g for g in permitidos if g]), key=lambda x: int(str(x).split("-")[0]) if str(x).split("-")[0].isdigit() else 999)
    existentes = set(grados_disponibles())
    return [g for g in permitidos if g in existentes] or permitidos


def estudiante_nombre(e):
    return f"{e.nombre} {e.apellido}".strip()


def buscar_estudiante_por_codigo_doc_nombre(valor):
    valor = (valor or "").strip()
    if not valor:
        return None
    return Estudiante.query.filter(or_(Estudiante.codigo == valor, Estudiante.documento == valor, func.lower(func.concat(Estudiante.nombre, ' ', Estudiante.apellido)).like(f"%{valor.lower()}%"))).first()


def limpiar_codigo(texto):
    texto = (texto or "").strip()
    texto = texto.replace("\r", "\n")

    # Formato nuevo del QR: solo contiene "Codigo: 22037974".
    # También soporta códigos viejos que traían más información.
    m = re.search(r"(?:Codigo|Código|CODIGO|codigo)\s*:\s*([^\n]+)", texto)
    if m:
        return m.group(1).strip().split()[0].strip()

    # Si algún QR llega como URL con ?codigo=..., lo soporta también.
    if "codigo=" in texto.lower() or "code=" in texto.lower():
        try:
            from urllib.parse import urlparse, parse_qs
            qs = parse_qs(urlparse(texto).query)
            valor = (qs.get("codigo") or qs.get("code") or qs.get("id") or [""])[0]
            if valor:
                return str(valor).strip()
        except Exception:
            pass

    # Último respaldo: toma el primer número largo del texto.
    m = re.search(r"\b\d{4,}\b", texto)
    if m:
        return m.group(0).strip()

    return texto.split("\n")[0].replace("#", "").strip()


def qr_texto(e):
    # IMPORTANTE: El QR ahora guarda SOLO el código del estudiante.
    # Así el lector no recibe nombres, grado ni otros datos y registra más rápido.
    return f"Codigo: {e.codigo}"


def login_usuario(usuario, password, rol_requerido=None):
    usuario=(usuario or "").strip(); password=(password or "").strip()
    u = Usuario.query.filter(func.lower(Usuario.usuario) == usuario.lower()).first()
    if not u or not verificar_password(u.password, password): return None
    if rol_requerido and u.rol.lower().strip() != rol_requerido.lower().strip(): return None
    if not es_hash_password(u.password):
        u.password = crear_hash(password); db.session.commit()
    return u


def requiere_login(): return "usuario" in session
def rol_actual(): return session.get("rol", "")
def es_admin_tecnico(): return rol_actual() in ["Administrador", "Soporte"]
def puede_admin(): return rol_actual() in ["Administrador", "Soporte"]
def puede_estudiantes(): return rol_actual() in ["Secretaría", "Administrador", "Soporte"]
def puede_buscar_estudiantes(): return rol_actual() in ["Rectoría", "Coordinación", "Secretaría", "Administrador", "Soporte"]
def puede_ingreso_manual(): return rol_actual() in ["Coordinación", "Secretaría", "Administrador", "Soporte"]
def puede_novedades(): return rol_actual() in ["Rectoría", "Coordinación", "Administrador", "Soporte"]
def puede_gestionar_novedades(): return rol_actual() in ["Coordinación", "Administrador", "Soporte"]
def puede_citaciones(): return rol_actual() in ["Rectoría", "Coordinación", "Administrador", "Soporte"]
def puede_reportes(): return rol_actual() in ["Rectoría", "Coordinación", "Administrador", "Soporte"]
def puede_reportes_padres(): return rol_actual() in ["Rectoría", "Coordinación", "Administrador", "Soporte"]
def puede_alertas(): return rol_actual() in ["Rectoría", "Coordinación", "Administrador", "Soporte"]
def puede_auditoria(): return rol_actual() in ["Rectoría", "Administrador", "Soporte"]
def puede_configurar(): return rol_actual() in ["Administrador", "Soporte", "Rectoría"]
def puede_ver_historial(): return rol_actual() in ["Rectoría", "Coordinación", "Secretaría", "Administrador", "Soporte"]

def dentro_horario_docente():
    actual = ahora().time()
    inicio = datetime.strptime(HORA_INICIO_ASISTENCIA, "%H:%M").time()
    fin = datetime.strptime(HORA_FIN_ASISTENCIA_DOCENTE, "%H:%M").time()
    return inicio <= actual <= fin

def aviso_horario_docente():
    return f"El registro docente está habilitado únicamente de {HORA_INICIO_ASISTENCIA} a {HORA_FIN_ASISTENCIA_DOCENTE}. Después de ese horario solo Coordinación puede registrar o corregir asistencia."

def verificar_codigo_auditoria(codigo):
    return check_password_hash(AUDITORIA_DELETE_HASH, codigo or "")

def estado_badge(estado):
    clase = "estado-temprano"
    if estado == "Tarde": clase = "estado-tarde"
    if estado == "No llegó": clase = "estado-no"
    return f'<span class="estado {clase}">{estado}</span>'


def registrar_ingreso(codigo, estado, registrado_por=None):
    codigo = limpiar_codigo(codigo)
    e = Estudiante.query.filter_by(codigo=codigo).first()
    if not e: return "Estudiante no registrado", "No registrado"
    if not registrado_por:
        registrado_por = f"{session.get('usuario', 'Portería')} ({session.get('rol', 'Portal móvil')})" if requiere_login() else "Portería / Portal móvil"
    ultimo = IngresoPorteria.query.filter_by(estudiante_id=e.id, fecha=fecha_hoy()).order_by(IngresoPorteria.id.desc()).first()
    if ultimo:
        return f"Entrada bloqueada: {e.nombre} {e.apellido} ya fue registrado hoy a las {ultimo.hora} por {ultimo.registrado_por}.", "Duplicado"
    db.session.add(IngresoPorteria(estudiante_id=e.id,fecha=fecha_hoy(),hora=hora_actual(),dia=ahora().strftime("%A"),estado=estado,periodo=periodo_actual(),registrado_por=registrado_por))
    db.session.commit()
    registrar_auditoria("Registro de ingreso", f"{e.codigo} - {e.nombre} {e.apellido} - {estado} - {registrado_por}")
    return f"Registro guardado: {e.nombre} {e.apellido} - {estado}", estado

def enviar_pin(correo_destino, pin):
    if not SOPORTE_EMAIL or not SOPORTE_PASSWORD: return False
    msg = EmailMessage(); msg["Subject"] = "PIN de recuperación - EduTrack QR"; msg["From"] = SOPORTE_EMAIL; msg["To"] = correo_destino
    msg.set_content(f"Tu PIN de recuperación es: {pin}\nEste PIN vence en 2 minutos.\n{APP_NAME}")
    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
            smtp.login(SOPORTE_EMAIL, SOPORTE_PASSWORD); smtp.send_message(msg)
        return True
    except Exception as e:
        print("ERROR PIN:", e); return False


@app.route("/")
def inicio(): return redirect("/login")


@app.route("/login", methods=["GET", "POST"])
def login():
    error = ""
    if request.method == "POST":
        user = login_usuario(request.form.get("usuario"), request.form.get("password"))
        if user:
            session["usuario"] = user.usuario; session["rol"] = user.rol; session["grupo_docente"] = user.grupo_docente or ""; session["password_temporal"] = bool(user.password_temporal); session["ultimo_movimiento"] = ahora().timestamp()
            registrar_auditoria("Inicio de sesión", f"Usuario {user.usuario} ingresó como {user.rol}")
            return redirect("/dashboard")
        error = "Usuario o contraseña incorrectos."
    return page("Login", f"""
<div class="center"><section class="card login-card"><div class="hero-logo"><img class="logo" src="/static/img/logo-colegio.png"><h2>{APP_NAME}</h2><p>{INST_NOMBRE}</p></div><h1>Iniciar sesión</h1><p>Acceso administrativo institucional.</p>{'<p class="error">'+error+'</p>' if error else ''}<form method="POST"><input name="usuario" placeholder="Usuario" required><input name="password" type="password" placeholder="Contraseña" required><button>Ingresar</button></form><p><a href="/recuperar">¿Olvidaste tu contraseña?</a> · <a href="/docente-login">Docentes</a> · <a href="/contacto">Contacto</a></p>{footer()}</section></div>
""")


@app.route("/recuperar", methods=["GET", "POST"])
def recuperar():
    mensaje = ""
    if request.method == "POST":
        usuario = request.form.get("usuario", "").strip(); correo = request.form.get("correo", "").strip()
        user = Usuario.query.filter(func.lower(Usuario.usuario) == usuario.lower(), Usuario.correo == correo).first()
        if user:
            pin = str(random.randint(100000, 999999)); vence = (ahora() + timedelta(minutes=2)).timestamp()
            Recuperacion.query.filter_by(usuario=user.usuario).delete(); db.session.add(Recuperacion(usuario=user.usuario, pin=f"{pin}|{vence}")); db.session.commit()
            if enviar_pin(correo, pin):
                session["recuperar_usuario"] = user.usuario; return redirect("/validar_pin")
            mensaje = "No se pudo enviar el correo. Revisa SOPORTE_EMAIL y SOPORTE_PASSWORD en Render."
        else: mensaje = "Usuario o correo no encontrado. Debe estar creado en Usuarios con ese correo."
    return page("Recuperar", f"""<div class="center"><section class="card login-card"><h1>Recuperar contraseña</h1><p>{mensaje}</p><form method="POST"><input name="usuario" placeholder="Usuario" required><input name="correo" placeholder="Correo registrado" required><button>Enviar PIN</button></form><p>El PIN vence en 2 minutos.</p><a href="/login">Volver</a></section></div>""")


@app.route("/validar_pin", methods=["GET", "POST"])
def validar_pin():
    if "recuperar_usuario" not in session: return redirect("/recuperar")
    mensaje = ""
    if request.method == "POST":
        r = Recuperacion.query.filter_by(usuario=session["recuperar_usuario"]).first()
        if r:
            partes = r.pin.split("|"); pin_real = partes[0]; vence = float(partes[1]) if len(partes) > 1 else 0
            if ahora().timestamp() > vence:
                Recuperacion.query.filter_by(usuario=session["recuperar_usuario"]).delete(); db.session.commit(); mensaje = "El PIN venció. Solicita uno nuevo."
            elif request.form.get("pin") == pin_real:
                u = Usuario.query.filter_by(usuario=session["recuperar_usuario"]).first(); u.password = crear_hash(request.form.get("password", "").strip()); u.password_temporal = False
                Recuperacion.query.filter_by(usuario=u.usuario).delete(); db.session.commit(); session.pop("recuperar_usuario", None); return redirect("/login")
            else: mensaje = "PIN incorrecto."
    return page("Validar PIN", f"""<div class="center"><section class="card login-card"><h1>Nueva contraseña</h1><p>{mensaje}</p><form method="POST"><input name="pin" placeholder="PIN recibido" required><input name="password" type="password" placeholder="Nueva contraseña" required><button>Guardar contraseña</button></form></section></div>""")



@app.route("/cambiar_password", methods=["GET", "POST"])
def cambiar_password():
    if not requiere_login(): return redirect("/login")
    mensaje = ""
    if request.method == "POST":
        nueva = request.form.get("password", "").strip()
        confirmar = request.form.get("confirmar", "").strip()
        if len(nueva) < 8:
            mensaje = "La contraseña debe tener mínimo 8 caracteres."
        elif nueva != confirmar:
            mensaje = "Las contraseñas no coinciden."
        else:
            u = Usuario.query.filter_by(usuario=session["usuario"]).first()
            u.password = crear_hash(nueva); u.password_temporal = False
            db.session.commit(); session["password_temporal"] = False
            registrar_auditoria("Cambio de contraseña", "Usuario cambió su contraseña temporal")
            return redirect("/dashboard")
    return page("Cambiar contraseña", f"""
<div class="center"><section class="card login-card"><h1>Cambiar contraseña</h1><p>Por seguridad debes cambiar la contraseña temporal antes de continuar.</p>{'<p class="error">'+mensaje+'</p>' if mensaje else ''}<form method="POST"><input name="password" type="password" placeholder="Nueva contraseña" required><input name="confirmar" type="password" placeholder="Confirmar contraseña" required><button>Guardar contraseña</button></form><a href="/logout">Salir</a></section></div>
""")


@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():
    if not requiere_login(): return redirect("/login")
    cfg = config()
    if request.method == "POST":
        if not puede_configurar(): return acceso_denegado()
        cfg.periodo_actual = request.form.get("periodo_actual", cfg.periodo_actual)
        cfg.jornada = request.form.get("jornada", cfg.jornada)
        if rol_actual() in ["Administrador", "Soporte"]:
            cfg.modo_mantenimiento = request.form.get("modo_mantenimiento") == "on"
            cfg.mensaje_mantenimiento = request.form.get("mensaje_mantenimiento", cfg.mensaje_mantenimiento)
            detalle_cfg = "Actualizó periodo, jornada o mantenimiento"
        else:
            detalle_cfg = "Rectoría actualizó periodo o jornada"
        db.session.commit(); registrar_auditoria("Configuración global", detalle_cfg)
        return redirect("/dashboard")

    hoy = fecha_hoy()
    estudiantes_total = Estudiante.query.count()
    ingresos_hoy = IngresoPorteria.query.filter_by(fecha=hoy).all()
    temprano = sum(1 for i in ingresos_hoy if i.estado == "Temprano")
    tarde = sum(1 for i in ingresos_hoy if i.estado == "Tarde")
    ids_ingreso = {i.estudiante_id for i in ingresos_hoy}
    no_llego = max(estudiantes_total - len(ids_ingreso), 0)
    usuarios_total = Usuario.query.count()
    auditorias_total = Auditoria.query.count()

    cards = f"""
    <div class='role-cards'>
      <div class='role-card'><h3>{estudiantes_total}</h3><p>Estudiantes</p></div>
      <div class='role-card green'><h3>{temprano}</h3><p>Temprano hoy</p></div>
      <div class='role-card yellow'><h3>{tarde}</h3><p>Tarde hoy</p></div>
      <div class='role-card red'><h3>{no_llego}</h3><p>No llegó</p></div>
    </div>
    """

    top = f"""
    <section class='role-hero'>
      <div><h1>Panel {rol_actual()}</h1><p><b>{INST_NOMBRE}</b> · Periodo <b>{periodo_actual()}</b> · Jornada <b>{jornada_actual()}</b></p><p>Usuario: <b>{session['usuario']}</b></p></div>
      <div class='top-actions'><a class='btn btn-red' href='/logout'>Salir</a></div>
    </section>
    """

    rol = rol_actual()
    if rol in ["Administrador", "Soporte"]:
        mantenimiento_checked = "checked" if cfg.modo_mantenimiento else ""
        body = f"""
        {cards}
        <section class='role-grid'>
          <div class='role-panel'><h2>Administración técnica</h2><ul><li>Usuarios registrados: <b>{usuarios_total}</b></li><li>Eventos de auditoría: <b>{auditorias_total}</b></li><li>Base de datos: <b>{'PostgreSQL' if 'postgresql' in DATABASE_URL else 'SQLite local'}</b></li></ul><a class='btn' href='/usuarios'>Gestionar usuarios</a> <a class='btn' href='/auditoria'>Ver auditoría</a> <a class='btn btn-green' href='/backup'>Descargar backup</a></div>
          <div class='role-panel'><h2>Configuración global</h2><form method='POST'><label>Periodo actual</label><select name='periodo_actual'><option {'selected' if periodo_actual()=='Periodo 1' else ''}>Periodo 1</option><option {'selected' if periodo_actual()=='Periodo 2' else ''}>Periodo 2</option><option {'selected' if periodo_actual()=='Periodo 3' else ''}>Periodo 3</option></select><label>Jornada</label><select name='jornada'><option {'selected' if jornada_actual()=='Mañana' else ''}>Mañana</option><option {'selected' if jornada_actual()=='Tarde' else ''}>Tarde</option><option {'selected' if jornada_actual()=='Única' else ''}>Única</option></select><label><input type='checkbox' name='modo_mantenimiento' style='width:auto' {mantenimiento_checked}> Activar modo mantenimiento</label><input name='mensaje_mantenimiento' value='{cfg.mensaje_mantenimiento}'><button>Guardar configuración</button></form></div>
        </section>
        """
    elif rol == "Rectoría":
        body = f"""
        {cards}
        <section class='role-grid'>
          <div class='role-panel'><h2>Vista estratégica</h2><p>Consulta global de asistencia y comportamiento institucional. No registra matrículas ni altera asistencia.</p><a class='btn' href='/reportes'>Reportes globales</a> <a class='btn' href='/reportes_padres'>Reportes padres</a> <a class='btn' href='/auditoria'>Auditoría</a> <a class='btn btn-green' href='/configuracion'>Cambiar periodo</a></div>
          <div class='role-panel'><h2>Lectura institucional</h2><ul><li>Ver reportes generales</li><li>Consultar historial de estudiantes</li><li>Revisar actividad del sistema</li></ul></div>
        </section>
        """
    elif rol == "Coordinación":
        ultimos = ''.join(f"<tr><td>{i.estudiante.grado}</td><td>{i.estudiante.nombre} {i.estudiante.apellido}</td><td>{i.hora}</td><td>{estado_badge(i.estado)}</td></tr>" for i in ingresos_hoy[-10:])
        body = f"""
        {cards}
        <section class='role-grid'>
          <div class='role-panel'><h2>Control y convivencia</h2><p>Gestiona alertas, tardanzas, inasistencias y excusas.</p><a class='btn' href='/alertas'>Ver alertas</a> <a class='btn' href='/excusas'>Excusas</a> <a class='btn' href='/reportes'>Reportes</a> <a class='btn' href='/reportes_padres'>Padres</a></div>
          <div class='role-panel'><h2>Últimos ingresos de hoy</h2><table><tr><th>Grupo</th><th>Estudiante</th><th>Hora</th><th>Estado</th></tr>{ultimos}</table></div>
        </section>
        """
    elif rol == "Secretaría":
        body = f"""
        {cards}
        <section class='role-grid'>
          <div class='role-panel'><h2>Matrículas y datos maestros</h2><p>Crear, editar y organizar datos básicos de estudiantes, carnés y QR.</p><a class='btn' href='/estudiantes'>Gestionar estudiantes</a> <a class='btn' href='/importar_estudiantes'>Importar Excel</a> <a class='btn btn-green' href='/exportar_estudiantes'>Exportar Excel</a></div>
          <div class='role-panel'><h2>Responsabilidad del rol</h2><ul><li>No modifica asistencia ni reportes disciplinarios.</li><li>No crea usuarios administrativos.</li><li>Solo gestiona datos básicos.</li></ul></div>
        </section>
        """
    elif rol == "Docente":
        return redirect("/docente-movil")
    else:
        body = "<div class='role-panel'><h2>Rol no reconocido</h2><p>Contacta al soporte técnico.</p></div>"
    return page("Dashboard", shell(top + body))



@app.route("/portal", methods=["GET", "POST"])
def portal():
    mensaje = ""; estado = ""
    if request.method == "POST":
        quien = f"{session.get('usuario')} ({rol_actual()})" if requiere_login() else "Portería / Portal móvil"
        mensaje, estado = registrar_ingreso(request.form.get("codigo"), request.form.get("estado", "Temprano"), quien)
    return page("Portal móvil", f"""
<div class="center portal-bg">
  <section class="card portal portal-fast">
    <img class="logo" src="/static/img/logo-colegio.png">
    <h1>Portal de Ingreso</h1>
    <p>Escaneo continuo. Acepta la cámara una sola vez y deja esta pantalla abierta.</p>

    <div class="msg warn">
      Usa Google Chrome normal, sin VPN ni navegador con escudo. Si el lector queda negro, toca Detener y luego Iniciar otra vez.
    </div>

    <button type="button" id="btn-camera">Iniciar lector QR</button>
    <button type="button" id="btn-stop" style="display:none;background:#dc2626;margin-left:6px">Detener</button>

    <div id="camera-status" class="msg warn" style="display:none"></div>
    <div id="scan-result" class="msg" style="display:none"></div>
    <div id="reader" class="qr-reader-box"></div>

    <form method="POST" id="portal-form" autocomplete="off">
      <input name="codigo" id="codigo" placeholder="Código del estudiante" required autocomplete="off" inputmode="numeric">
      <select name="estado" id="estado"><option>Temprano</option><option>Tarde</option><option>No llegó</option></select>
      <button>Guardar ingreso manual</button>
    </form>

    {'<div class="msg ok">'+mensaje+'</div>' if mensaje and estado not in ['No registrado','Duplicado'] else ''}
    {'<div class="msg danger">'+mensaje+'</div>' if mensaje and estado in ['No registrado','Duplicado'] else ''}
    <p><a href="/login">Administración</a></p>
    {footer()}
  </section>
</div>

<script src="https://unpkg.com/html5-qrcode"></script>
<script>
let scanner = null;
let ultimoCodigo = "";
let ultimoTiempo = 0;
let registrando = false;

function limpiarCodigoQR(texto){{
  texto = (texto || '').trim().replace(/\\r/g, '\\n');
  const m = texto.match(/(?:Codigo|Código|CODIGO|codigo)\\s*:\\s*([^\\n]+)/);
  if(m && m[1]) return m[1].trim().split(/\\s+/)[0];
  const n = texto.match(/\\b\\d{{4,20}}\\b/);
  if(n) return n[0].trim();
  return texto.split('\\n')[0].replace(/^#/, '').trim();
}}

function mostrarEstado(txt, tipo='warn'){{
  const box = document.getElementById('camera-status');
  box.style.display = 'block';
  box.className = 'msg ' + tipo;
  box.innerHTML = txt;
}}

function mostrarResultado(txt, tipo='ok'){{
  const box = document.getElementById('scan-result');
  box.style.display = 'block';
  box.className = 'msg ' + tipo;
  box.innerText = txt;
}}

async function registrarCodigo(codigo){{
  codigo = limpiarCodigoQR(codigo);
  if(!codigo) return;

  const ahora = Date.now();
  if(registrando) return;
  if(codigo === ultimoCodigo && (ahora - ultimoTiempo) < 6000) return;

  ultimoCodigo = codigo;
  ultimoTiempo = ahora;
  registrando = true;
  document.getElementById('codigo').value = codigo;
  mostrarResultado('Registrando ' + codigo + '...', 'warn');

  try {{
    const form = new FormData();
    form.append('codigo', codigo);
    form.append('estado', document.getElementById('estado').value || 'Temprano');

    const resp = await fetch('/portal_registrar_ajax', {{method:'POST', body:form, cache:'no-store'}});
    const data = await resp.json();

    if(data.ok){{
      mostrarResultado('✅ ' + data.mensaje, 'ok');
      try{{ navigator.vibrate && navigator.vibrate(120); }}catch(e){{}}
    }} else {{
      mostrarResultado('⚠️ ' + data.mensaje, 'danger');
    }}
  }} catch(e) {{
    console.error(e);
    mostrarResultado('Error de conexión. Registra manualmente.', 'danger');
  }} finally {{
    setTimeout(() => registrando = false, 800);
  }}
}}

async function iniciarLector(){{
  try {{
    if(!window.Html5Qrcode){{
      mostrarEstado('No cargó el lector QR. Revisa internet y recarga.', 'danger');
      return;
    }}
    scanner = new Html5Qrcode("reader");
    document.getElementById('btn-camera').style.display = 'none';
    document.getElementById('btn-stop').style.display = 'inline-block';
    mostrarEstado('Solicitando cámara... acepta el permiso.', 'warn');

    const config = {{ fps: 12, qrbox: {{ width: 250, height: 250 }}, aspectRatio: 1.0 }};

    try {{
      await scanner.start({{ facingMode: "environment" }}, config, decodedText => registrarCodigo(decodedText));
    }} catch(e1) {{
      console.warn(e1);
      const cams = await Html5Qrcode.getCameras();
      if(!cams || !cams.length) throw new Error('No se encontraron cámaras.');
      const back = cams.find(c => /back|rear|environment|trasera|posterior/i.test(c.label || '')) || cams[cams.length - 1];
      await scanner.start(back.id, config, decodedText => registrarCodigo(decodedText));
    }}

    mostrarEstado('✅ Cámara activa. Pasa los carnés uno por uno sin cerrar esta pantalla.', 'ok');
  }} catch(e) {{
    console.error(e);
    document.getElementById('btn-camera').style.display = 'inline-block';
    document.getElementById('btn-stop').style.display = 'none';
    mostrarEstado('No se pudo abrir la cámara. Usa Chrome normal, permite cámara en Configuración del sitio y desactiva VPN/escudo. También puedes ingresar el código manual.', 'danger');
  }}
}}

async function detenerLector(){{
  try {{
    if(scanner) {{
      await scanner.stop();
      await scanner.clear();
      scanner = null;
    }}
  }} catch(e) {{ console.warn(e); }}
  document.getElementById('btn-camera').style.display = 'inline-block';
  document.getElementById('btn-stop').style.display = 'none';
  mostrarEstado('Lector detenido.', 'warn');
}}

document.getElementById('btn-camera').addEventListener('click', iniciarLector);
document.getElementById('btn-stop').addEventListener('click', detenerLector);
document.getElementById('portal-form').addEventListener('submit', function(ev){{
  ev.preventDefault();
  registrarCodigo(document.getElementById('codigo').value);
}});
document.getElementById('codigo').addEventListener('keydown', function(ev){{
  if(ev.key === 'Enter'){{ ev.preventDefault(); registrarCodigo(this.value); }}
}});
</script>

<style>
.qr-reader-box{{width:100%;max-width:420px;min-height:330px;margin:14px auto;border-radius:20px;overflow:hidden;background:#0f172a;display:flex;align-items:center;justify-content:center}}
#reader video{{width:100%!important;height:100%!important;object-fit:cover!important}}
.portal-fast button{{margin-top:8px}}
.portal-fast .msg{{font-size:14px}}
</style>
""")

@app.route("/portal_registrar_ajax", methods=["POST"])
def portal_registrar_ajax():
    codigo = request.form.get("codigo", "")
    estado = request.form.get("estado", "Temprano")
    quien = f"{session.get('usuario')} ({rol_actual()})" if requiere_login() else "Portería / Portal móvil"
    mensaje, estado_res = registrar_ingreso(codigo, estado, quien)
    return jsonify({"ok": estado_res not in ["No registrado", "Duplicado"], "mensaje": mensaje, "estado": estado_res})


@app.route("/docente-login", methods=["GET", "POST"])
def docente_login():
    error = ""
    if request.method == "POST":
        u = login_usuario(request.form.get("usuario"), request.form.get("password"), "Docente")
        if u:
            session["usuario"] = u.usuario; session["rol"] = u.rol; session["grupo_docente"] = u.grupo_docente or ""; return redirect("/docente-movil")
        error = "Usuario docente incorrecto."
    return page("Portal docente", f"""<div class="center"><section class="card login-card"><img class="logo" src="/static/img/logo-colegio.png"><h1>Portal Docente</h1><p>Asistencia en aula.</p>{'<p class="error">'+error+'</p>' if error else ''}<form method="POST"><input name="usuario" placeholder="Usuario docente" required><input name="password" type="password" placeholder="Contraseña" required><button>Ingresar</button></form><p>Prueba: docente / 1234</p><a href="/login">Volver</a>{footer()}</section></div>""")



@app.route("/docente-movil", methods=["GET", "POST"])
def docente_movil():
    if not requiere_login() or rol_actual() != "Docente":
        return redirect("/docente-login")
    grupos = grados_docente_autorizados()
    grupo = request.args.get("grupo") or session.get("grupo_docente") or (grupos[0] if grupos else "")
    if rol_actual() == "Docente" and grupos and grupo not in grupos:
        grupo = grupos[0]
    mensaje = ""
    if request.method == "POST":
        if not dentro_horario_docente():
            mensaje = aviso_horario_docente()
        else:
            grupo = request.form.get("grupo")
            for e in Estudiante.query.filter_by(grado=grupo).all():
                estado = request.form.get(f"estado_{e.id}", "Presente")
                obs = request.form.get(f"obs_{e.id}", "")
                db.session.add(AsistenciaClase(estudiante_id=e.id, docente=session["usuario"], grupo=grupo, fecha=fecha_hoy(), hora=hora_actual(), estado=estado, periodo=periodo_actual(), observacion=obs))
                if estado == "Excusa":
                    db.session.add(Excusa(estudiante_id=e.id, fecha=fecha_hoy(), motivo=obs or "Excusa registrada", registrado_por=session["usuario"], periodo=periodo_actual()))
            db.session.commit()
            registrar_auditoria("Asistencia docente", f"Docente {session['usuario']} registró asistencia del grupo {grupo}")
            mensaje = "Asistencia guardada correctamente."

    opciones = ''.join(f'<option value="{g}" {"selected" if g==grupo else ""}>{g}-01-MAÑANA</option>' for g in grupos)
    estudiantes = Estudiante.query.filter_by(grado=grupo).order_by(Estudiante.nombre.asc()).all()
    cards = ''.join(f"""
      <div class='teacher-card'>
        <h3>{e.nombre} {e.apellido}</h3>
        <p><b>Código:</b> {e.codigo} · <b>Grado:</b> {e.grado}</p>
        <div class='teacher-options'>
          <select name='estado_{e.id}'>
            <option>Presente</option>
            <option>Ausente</option>
            <option>Tarde</option>
            <option>Excusa</option>
          </select>
          <input name='obs_{e.id}' placeholder='Observación'>
        </div>
      </div>
    """ for e in estudiantes)
    bloqueo = "" if dentro_horario_docente() else f"<div class='msg danger'>{aviso_horario_docente()}</div>"
    content = f"""
<section class='teacher-mobile'>
  <div class='mobile-top'>
    <h1>App docentes</h1>
    <p>Docente: <b>{session['usuario']}</b> · Periodo: <b>{periodo_actual()}</b></p>
    <p>Control de asistencia pensado para celular.</p>
    <a class='btn btn-red' href='/logout'>Salir</a>
  </div>
  {bloqueo}
  {'<div class="msg ok">'+mensaje+'</div>' if mensaje and 'guardada' in mensaje else ''}
  {'<div class="msg danger">'+mensaje+'</div>' if mensaje and 'guardada' not in mensaje else ''}
  <div class='mobile-top'>
    <form method='GET'>
      <label><b>Grupo</b></label>
      <select name='grupo'>{opciones}</select>
      <button>Ver grupo</button>
    </form>
  </div>
  <form method='POST'>
    <input type='hidden' name='grupo' value='{grupo}'>
    {cards if cards else "<div class='teacher-card'><h3>No hay estudiantes en este grupo.</h3></div>"}
    <button style='width:100%;margin-top:12px' {'disabled' if not dentro_horario_docente() else ''}>Guardar asistencia</button>
  </form>
</section>
"""
    return page("App docentes", shell(content))


@app.route("/docente", methods=["GET", "POST"])
def docente():
    if not requiere_login() or rol_actual() not in ["Docente", "Coordinación", "Administrador", "Soporte"]:
        return redirect("/docente-login")
    grupos = grados_docente_autorizados()
    grupo = request.args.get("grupo") or session.get("grupo_docente") or (grupos[0] if grupos else "")
    if rol_actual() == "Docente" and grupos and grupo not in grupos:
        grupo = grupos[0]
    mensaje = ""
    if request.method == "POST":
        if rol_actual() == "Docente" and not dentro_horario_docente():
            mensaje = aviso_horario_docente()
        else:
            grupo = request.form.get("grupo")
            for e in Estudiante.query.filter_by(grado=grupo).all():
                estado = request.form.get(f"estado_{e.id}", "Presente")
                obs = request.form.get(f"obs_{e.id}", "")
                db.session.add(AsistenciaClase(estudiante_id=e.id, docente=session["usuario"], grupo=grupo, fecha=fecha_hoy(), hora=hora_actual(), estado=estado, periodo=periodo_actual(), observacion=obs))
                if estado == "Excusa":
                    db.session.add(Excusa(estudiante_id=e.id, fecha=fecha_hoy(), motivo=obs or "Excusa registrada", registrado_por=session["usuario"], periodo=periodo_actual()))
            db.session.commit()
            registrar_auditoria("Registro/corrección asistencia", f"{session['usuario']} registró asistencia del grupo {grupo}")
            mensaje = "Asistencia guardada correctamente."
    opciones = ''.join(f'<option value="{g}" {"selected" if g==grupo else ""}>{g}-01-MAÑANA</option>' for g in grupos)
    estudiantes = Estudiante.query.filter_by(grado=grupo).order_by(Estudiante.nombre.asc()).all()
    filas = ''.join(f"<tr><td>{e.codigo}</td><td>{e.nombre} {e.apellido}</td><td>{e.grado}</td><td>{e.director}</td><td><select name='estado_{e.id}'><option>Presente</option><option>Ausente</option><option>Tarde</option><option>Excusa</option></select></td><td><input name='obs_{e.id}' placeholder='Observación'></td></tr>" for e in estudiantes)
    aviso = ""
    if rol_actual() == "Docente" and not dentro_horario_docente(): aviso = f"<div class='msg danger'>{aviso_horario_docente()}</div>"
    content = f"""<header class="header"><div class="header-info"><img src="/static/img/logo-colegio.png"><div><h1>Control de Asistencia</h1><p>Usuario: {session['usuario']} · Rol: {rol_actual()} · Periodo: {periodo_actual()}</p></div></div><a class="btn btn-red" href="/logout">Salir</a></header>{aviso}{'<div class="msg ok">'+mensaje+'</div>' if mensaje and 'guardada' in mensaje else ''}{'<div class="msg danger">'+mensaje+'</div>' if mensaje and 'guardada' not in mensaje else ''}<div class="panel-box"><form method="GET"><label>Grupo</label><select name="grupo">{opciones}</select><button>Ver grupo</button></form></div><div class="table-card"><h2>Asistencia grupo {grupo}</h2><form method="POST"><input type="hidden" name="grupo" value="{grupo}"><table><tr><th>Código</th><th>Nombre</th><th>Grado</th><th>Director</th><th>Estado</th><th>Observación</th></tr>{filas}</table><br><button {'disabled' if rol_actual()=='Docente' and not dentro_horario_docente() else ''}>Guardar asistencia</button></form></div>"""
    return page("Asistencia", shell(content))



@app.route("/estudiantes", methods=["GET", "POST"])
def estudiantes():
    if not requiere_login(): return redirect("/login")
    # Compatibilidad con enlaces antiguos: ahora los módulos están separados.
    if rol_actual() == "Secretaría":
        return redirect("/registrar_estudiante")
    return redirect("/buscar_estudiantes")


@app.route("/registrar_estudiante", methods=["GET", "POST"])
def registrar_estudiante():
    if not requiere_login(): return redirect("/login")
    if not puede_estudiantes(): return acceso_denegado("Solo Secretaría, Soporte o Administrador pueden registrar o actualizar estudiantes.")

    mensaje = ""
    if request.method == "POST":
        codigo = request.form.get("codigo", "").strip()
        if codigo:
            e = Estudiante.query.filter_by(codigo=codigo).first()
            if not e:
                e = Estudiante(codigo=codigo)
                db.session.add(e)
                mensaje = "Alumno registrado correctamente."
            else:
                mensaje = "Alumno actualizado correctamente."

            e.nombre = request.form.get("nombre", "").strip()
            e.apellido = request.form.get("apellido", "").strip()
            e.grado = request.form.get("grado", "").strip()
            e.director = request.form.get("director", "").strip()
            e.documento = request.form.get("documento", "").strip()
            e.rh = request.form.get("rh", "").strip()
            e.acudiente = request.form.get("acudiente", "").strip()
            e.padre = request.form.get("padre", "").strip()
            e.madre = request.form.get("madre", "").strip()
            e.telefono_acudiente = request.form.get("telefono_acudiente", "").strip()
            e.correo_acudiente = request.form.get("correo_acudiente", "").strip()
            e.direccion = request.form.get("direccion", "").strip()
            e.observacion = request.form.get("observacion", "").strip()
            db.session.commit()
            registrar_auditoria("Guardar estudiante", f"{codigo} - {e.nombre} {e.apellido} - grado {e.grado}")

    content = f"""
<header class="header">
  <div class="header-info">
    <img src="/static/img/logo-colegio.png">
    <div>
      <h1>Registrar / actualizar estudiante</h1>
      <p>Este módulo es independiente de la búsqueda y de los listados. Uso principal: Secretaría.</p>
    </div>
  </div>
  <a class="btn" href="/buscar_estudiantes">Buscar estudiantes</a>
</header>

<section class="student-form-card" style="max-width:980px;margin:auto">
  {'<div class="msg ok">'+mensaje+'</div>' if mensaje else ''}
  <form method="POST">
    <div class="student-section-title">Datos personales</div>
    <input name="codigo" placeholder="Código del estudiante" required>
    <div class="form-row">
      <input name="nombre" placeholder="Nombre" required>
      <input name="apellido" placeholder="Apellido" required>
    </div>

    <div class="student-section-title">Datos académicos</div>
    <div class="form-row">
      <select name="grado" required>
        <option value="">Seleccione grado</option>
        <option>6</option><option>7</option><option>8</option>
        <option>9</option><option>10</option><option>11</option>
      </select>
      <input value="{fecha_hoy()}" readonly>
    </div>
    <input name="director" placeholder="Director de grupo" required>

    <div class="student-section-title">Datos familiares y contacto</div>
    <div class="form-row">
      <input name="documento" placeholder="Documento del estudiante">
      <input name="rh" placeholder="RH / Grupo sanguíneo">
    </div>
    <input name="acudiente" placeholder="Acudiente principal">
    <div class="form-row">
      <input name="padre" placeholder="Padre">
      <input name="madre" placeholder="Madre">
    </div>
    <div class="form-row">
      <input name="correo_acudiente" placeholder="Correo acudiente">
      <input name="telefono_acudiente" placeholder="Teléfono acudiente">
    </div>
    <input name="direccion" placeholder="Dirección">
    <textarea name="observacion" placeholder="Observaciones institucionales"></textarea>

    <div class="student-actions">
      <button>Guardar estudiante</button>
      <a class="btn btn-green" href="/importar_estudiantes">Importar Excel</a>
      <a class="btn" href="/buscar_estudiantes">Ir a búsqueda</a>
    </div>
  </form>
</section>
"""
    return page("Registrar estudiante", shell(content))


def consulta_estudiantes_filtrada():
    grado_filtro = request.args.get("grado", "").strip()
    periodo_filtro = request.args.get("periodo", periodo_actual()).strip()
    buscar = request.args.get("buscar", "").strip()

    consulta = Estudiante.query
    hay_filtro = False

    if grado_filtro and grado_filtro not in ["TODOS", ""]:
        consulta = consulta.filter(Estudiante.grado == grado_filtro)
        hay_filtro = True

    if buscar:
        patron = f"%{buscar}%"
        consulta = consulta.filter(
            or_(
                Estudiante.codigo.ilike(patron),
                Estudiante.nombre.ilike(patron),
                Estudiante.apellido.ilike(patron),
                Estudiante.documento.ilike(patron),
                func.concat(Estudiante.nombre, " ", Estudiante.apellido).ilike(patron)
            )
        )
        hay_filtro = True

    if not hay_filtro:
        return [], grado_filtro, periodo_filtro, buscar, False

    return consulta.order_by(Estudiante.grado.asc(), Estudiante.nombre.asc()).all(), grado_filtro, periodo_filtro, buscar, True


def tabla_estudiantes(estudiantes_filtrados):
    filas = ''.join(f"""<tr>
<td><span class="student-pill">{e.codigo}</span></td>
<td><b>{e.nombre} {e.apellido}</b><br><span class="mini-text">Doc: {e.documento or 'Sin documento'}</span></td>
<td>{e.grado}</td>
<td>{e.acudiente or '-'}</td>
<td>{e.telefono_acudiente or '-'}</td>
<td><img class="qr-mini" src="/qr/{e.id}"></td>
<td>
  <a href="/ficha_estudiante/{e.id}">Ficha</a> ·
  <a href="/qr_descargar/{e.id}">QR</a> ·
  <a href="/carnet/{e.id}">Carné</a> ·
  <a href="/historial/{e.id}">Historial</a> ·
  <a class="danger-link" href="/eliminar_estudiante/{e.id}">Eliminar</a>
</td>
</tr>""" for e in estudiantes_filtrados)
    return filas


@app.route("/buscar_estudiantes")
def buscar_estudiantes():
    if not requiere_login(): return redirect("/login")
    if not puede_buscar_estudiantes(): return acceso_denegado()

    estudiantes_filtrados, grado_filtro, periodo_filtro, buscar, hay_filtro = consulta_estudiantes_filtrada()

    opciones_grado = '<option value="">Seleccione grado</option><option value="TODOS">TODOS LOS GRADOS</option>' + ''.join(
        f'<option value="{g}" {"selected" if grado_filtro == g else ""}>{g}</option>' for g in grados_disponibles()
    )
    opciones_periodo = ''.join(
        f'<option value="{p}" {"selected" if periodo_filtro == p else ""}>{p}</option>' for p in ["Periodo 1", "Periodo 2", "Periodo 3"]
    )
    filas = tabla_estudiantes(estudiantes_filtrados)

    content = f"""
<header class="header">
  <div class="header-info">
    <img src="/static/img/logo-colegio.png">
    <div>
      <h1>Buscar estudiante</h1>
      <p>Busca por nombre completo, documento o código. No se cargan todos por defecto para mantener orden.</p>
    </div>
  </div>
</header>

<section class="student-list-card">
  <h2>Búsqueda individual o avanzada</h2>
  <form method="GET" class="filter-bar">
    <div class="form-row">
      <div><label><b>Buscar estudiante</b></label><input name="buscar" value="{buscar}" placeholder="Nombre completo, documento o código"></div>
      <div><label><b>Grado</b></label><select name="grado">{opciones_grado}</select></div>
    </div>
    <div class="form-row">
      <div><label><b>Periodo</b></label><select name="periodo">{opciones_periodo}</select></div>
      <div style="display:flex;gap:10px;align-items:end"><button style="width:100%">Consultar</button><a class="btn" href="/buscar_estudiantes">Limpiar</a></div>
    </div>
  </form>

  <div class="student-table-wrap">
    <table class="student-table">
      <tr><th>Código</th><th>Estudiante</th><th>Grado</th><th>Acudiente</th><th>Teléfono</th><th>QR</th><th>Acciones</th></tr>
      {filas if hay_filtro and filas else ('<tr><td colspan="7">No se encontraron estudiantes con esos filtros.</td></tr>' if hay_filtro else '<tr><td colspan="7">Usa los filtros para buscar. Ejemplo: grado 8, documento, código o nombre.</td></tr>')}
    </table>
  </div>
</section>
"""
    return page("Buscar estudiante", shell(content))


@app.route("/estudiantes_grupo")
def estudiantes_grupo():
    if not requiere_login(): return redirect("/login")
    if not puede_buscar_estudiantes(): return acceso_denegado()

    grado_filtro = request.args.get("grado", "").strip()
    periodo_filtro = request.args.get("periodo", periodo_actual()).strip()
    estudiantes_filtrados = []
    if grado_filtro:
        estudiantes_filtrados = Estudiante.query.filter_by(grado=grado_filtro).order_by(Estudiante.nombre.asc()).all()

    opciones_grado = '<option value="">Seleccione grado</option>' + ''.join(
        f'<option value="{g}" {"selected" if grado_filtro == g else ""}>{g}</option>' for g in grados_disponibles()
    )
    opciones_periodo = ''.join(
        f'<option value="{p}" {"selected" if periodo_filtro == p else ""}>{p}</option>' for p in ["Periodo 1", "Periodo 2", "Periodo 3"]
    )
    filas = tabla_estudiantes(estudiantes_filtrados)

    content = f"""
<header class="header">
  <div class="header-info">
    <img src="/static/img/logo-colegio.png">
    <div>
      <h1>Grupos de estudiantes</h1>
      <p>Consulta separada por grado. No mezcla todos los estudiantes en una sola vista.</p>
    </div>
  </div>
</header>

<section class="student-list-card">
  <form method="GET" class="filter-bar">
    <div class="form-row">
      <div><label><b>Grado</b></label><select name="grado" required>{opciones_grado}</select></div>
      <div><label><b>Periodo</b></label><select name="periodo">{opciones_periodo}</select></div>
    </div>
    <button>Consultar grupo</button>
  </form>
  <div class="student-table-wrap">
    <table class="student-table">
      <tr><th>Código</th><th>Estudiante</th><th>Grado</th><th>Acudiente</th><th>Teléfono</th><th>QR</th><th>Acciones</th></tr>
      {filas if grado_filtro and filas else ('<tr><td colspan="7">No hay estudiantes en este grado.</td></tr>' if grado_filtro else '<tr><td colspan="7">Selecciona un grado para ver estudiantes.</td></tr>')}
    </table>
  </div>
</section>
"""
    return page("Grupos de estudiantes", shell(content))


@app.route("/ingreso_manual", methods=["GET", "POST"])
def ingreso_manual():
    if not requiere_login(): return redirect("/login")
    if not puede_ingreso_manual(): return acceso_denegado("Solo Coordinación, Secretaría o Soporte pueden registrar ingreso manual.")

    mensaje = ""
    estado_msg = ""
    if request.method == "POST":
        codigo = request.form.get("codigo")
        estado = request.form.get("estado", "Temprano")
        quien = f"{session.get('usuario')} ({rol_actual()})"
        mensaje, estado_msg = registrar_ingreso(codigo, estado, quien)

    estudiantes_filtrados, grado_filtro, periodo_filtro, buscar, hay_filtro = consulta_estudiantes_filtrada()
    opciones_grado = '<option value="">Seleccione grado</option><option value="TODOS">TODOS LOS GRADOS</option>' + ''.join(
        f'<option value="{g}" {"selected" if grado_filtro == g else ""}>{g}</option>' for g in grados_disponibles()
    )
    filas = ''.join(f"""<tr>
<td><span class="student-pill">{e.codigo}</span></td>
<td><b>{e.nombre} {e.apellido}</b><br><span class="mini-text">Doc: {e.documento or 'Sin documento'}</span></td>
<td>{e.grado}</td>
<td>
  <form method="POST" style="display:flex;gap:8px;align-items:center">
    <input type="hidden" name="codigo" value="{e.codigo}">
    <select name="estado" style="min-width:130px"><option>Temprano</option><option>Tarde</option><option>No llegó</option></select>
    <button class="small-action">Registrar</button>
  </form>
</td>
</tr>""" for e in estudiantes_filtrados)

    content = f"""
<header class="header">
  <div class="header-info"><img src="/static/img/logo-colegio.png"><div><h1>Ingreso manual autorizado</h1><p>Para estudiantes sin carné, olvidado o dañado. Queda registrado quién reporta.</p></div></div>
</header>
{'<div class="msg ok">'+mensaje+'</div>' if mensaje and estado_msg not in ['No registrado','Duplicado'] else ''}
{'<div class="msg danger">'+mensaje+'</div>' if mensaje and estado_msg in ['No registrado','Duplicado'] else ''}
<section class="student-list-card">
  <form method="GET" class="filter-bar">
    <div class="form-row">
      <div><label><b>Buscar estudiante</b></label><input name="buscar" value="{buscar}" placeholder="Nombre, documento o código"></div>
      <div><label><b>Grado</b></label><select name="grado">{opciones_grado}</select></div>
    </div>
    <button>Buscar para registrar</button>
  </form>
  <table class="student-table"><tr><th>Código</th><th>Estudiante</th><th>Grado</th><th>Registrar ingreso</th></tr>
  {filas if hay_filtro and filas else ('<tr><td colspan="4">Usa búsqueda o grado para registrar ingreso manual.</td></tr>' if not hay_filtro else '<tr><td colspan="4">No hay resultados.</td></tr>')}
  </table>
</section>
"""
    return page("Ingreso manual", shell(content))


@app.route("/carnes")
def carnes():
    if not requiere_login(): return redirect("/login")
    if rol_actual() not in ["Secretaría", "Coordinación", "Administrador", "Soporte"]: return acceso_denegado()
    return redirect("/buscar_estudiantes")

@app.route("/eliminar_estudiante/<int:id>")
def eliminar_estudiante(id):
    if not requiere_login(): return redirect("/login")
    if not puede_estudiantes(): return acceso_denegado()
    e = Estudiante.query.get_or_404(id); registrar_auditoria("Eliminar estudiante", f"{e.codigo} - {e.nombre} {e.apellido}"); IngresoPorteria.query.filter_by(estudiante_id=e.id).delete(); AsistenciaClase.query.filter_by(estudiante_id=e.id).delete(); Excusa.query.filter_by(estudiante_id=e.id).delete(); db.session.delete(e); db.session.commit(); return redirect("/estudiantes")


@app.route("/qr/<int:id>")
def qr_estudiante(id):
    e = Estudiante.query.get_or_404(id); img = qrcode.make(qr_texto(e)); b = BytesIO(); img.save(b, format="PNG"); b.seek(0); return send_file(b, mimetype="image/png")


@app.route("/qr_descargar/<int:id>")
def qr_descargar(id):
    e = Estudiante.query.get_or_404(id); img = qrcode.make(qr_texto(e)); b = BytesIO(); img.save(b, format="PNG"); b.seek(0); return send_file(b, mimetype="image/png", as_attachment=True, download_name=f"{e.codigo}.png")


@app.route("/carnet/<int:id>")
def carnet(id):
    e = Estudiante.query.get_or_404(id)
    return page("Carné", f"""<div class="print-wrap"><div class="carnet"><div class="carnet-head"><img class="logo" src="/static/img/logo-colegio.png"><h3>{INST_NOMBRE}</h3><p>Sede {INST_SEDE}</p></div><h2>{e.nombre} {e.apellido}</h2><p><b>Grado:</b> {e.grado}</p><p><b>Director:</b> {e.director}</p><p><b>Código:</b> {e.codigo}</p><img class="qr" src="/qr/{e.id}"><p>{APP_NAME}</p></div><br><button class="no-print" onclick="window.print()">Imprimir carné</button><br><a class="no-print" href="/estudiantes">Volver</a></div>""")


@app.route("/usuarios", methods=["GET", "POST"])
def usuarios():
    if not requiere_login(): return redirect("/login")
    if not puede_admin(): return acceso_denegado()
    if request.method == "POST":
        usuario = request.form.get("usuario", "").strip()
        if usuario and not Usuario.query.filter(func.lower(Usuario.usuario) == usuario.lower()).first():
            temp = request.form.get("password", "Colegio2026*").strip() or "Colegio2026*"
            db.session.add(Usuario(
                usuario=usuario,
                password=crear_hash(temp),
                rol=request.form.get("rol"),
                correo=request.form.get("correo", "").strip(),
                grupo_docente=request.form.get("grupo_docente", "").strip(),
                grados_clase=request.form.get("grados_clase", "").strip(),
                password_temporal=True
            ))
            db.session.commit()
            registrar_auditoria("Crear usuario", f"Creó usuario {usuario} con rol {request.form.get('rol')}")
        return redirect("/usuarios")
    filas = ''.join(f"<tr><td>{u.usuario}</td><td>{u.rol}</td><td>{u.correo}</td><td>{u.grupo_docente}</td><td>{getattr(u,'grados_clase','')}</td><td>{'Sí' if u.password_temporal else 'No'}</td><td><a class='btn small-action' href='/reset_usuario/{u.id}'>Restablecer</a> <a class='danger-link' href='/eliminar_usuario/{u.id}'>Eliminar</a></td></tr>" for u in Usuario.query.order_by(Usuario.rol.asc()).all())
    content = f"""
<header class="role-hero"><div><h1>Gestión de usuarios</h1><p>Crear cuentas, asignar roles y configurar docentes por grados.</p></div><a class="btn" href="/dashboard">Volver</a></header>
<section class="role-grid">
<div class="role-panel"><h2>Crear usuario</h2><form method="POST"><input name="usuario" placeholder="Usuario, ejemplo: profe_santiago" required><input name="password" type="text" placeholder="Contraseña temporal" value="Colegio2026*" required><input name="correo" placeholder="Correo de recuperación"><select name="rol"><option>Rectoría</option><option>Coordinación</option><option>Secretaría</option><option>Docente</option><option>Soporte</option><option>Administrador</option></select><input name="grupo_docente" placeholder="Si es director de grupo, ejemplo: 10"><input name="grados_clase" placeholder="Grados donde dicta clase, ejemplo: 8,9,11"><button>Crear usuario</button></form><div class='security-note'>Para docentes: grupo director es su grupo principal; grados clase define los grados que puede ver para listas.</div></div>
<div class="role-panel"><h2>Reglas de seguridad</h2><ul><li>Contraseñas encriptadas.</li><li>Restablecimiento manual por soporte.</li><li>Sesión expira por inactividad.</li><li>Docentes solo ven sus grados asignados.</li></ul></div>
</section>
<div class="table-card"><h2>Usuarios registrados</h2><table><tr><th>Usuario</th><th>Rol</th><th>Correo</th><th>Director grupo</th><th>Grados clase</th><th>Clave temporal</th><th>Acción</th></tr>{filas}</table></div>
"""
    return page("Usuarios", shell(content))


@app.route("/reset_usuario/<int:id>")
def reset_usuario(id):
    if not requiere_login(): return redirect("/login")
    if not puede_admin(): return acceso_denegado()
    u = Usuario.query.get_or_404(id)
    u.password = crear_hash("Colegio2026*")
    u.password_temporal = True
    db.session.commit()
    registrar_auditoria("Restablecer contraseña", f"Restableció clave temporal para {u.usuario}")
    return redirect("/usuarios")


@app.route("/eliminar_usuario/<int:id>")
def eliminar_usuario(id):
    if not requiere_login(): return redirect("/login")
    if not puede_admin(): return acceso_denegado()
    u = Usuario.query.get_or_404(id)
    if u.usuario != session.get("usuario"):
        registrar_auditoria("Eliminar usuario", f"Eliminó usuario {u.usuario} rol {u.rol}")
        db.session.delete(u); db.session.commit()
    return redirect("/usuarios")


@app.route("/historial/<int:id>")
def historial(id):
    if not requiere_login(): return redirect("/login")
    if not puede_ver_historial(): return acceso_denegado()
    e = Estudiante.query.get_or_404(id); ingresos = IngresoPorteria.query.filter_by(estudiante_id=id).order_by(IngresoPorteria.fecha.desc()).all()
    filas = ''.join(f"<tr><td>{i.fecha}</td><td>{i.hora}</td><td>{i.estado}</td><td>{i.periodo}</td><td>{i.registrado_por}</td></tr>" for i in ingresos)
    return page("Historial", shell(f"<header class='header'><div class='header-info'><img src='/static/img/logo-colegio.png'><div><h1>Historial de {e.nombre} {e.apellido}</h1><p>Grado {e.grado}</p></div></div><a class='btn' href='/estudiantes'>Volver</a></header><div class='table-card'><h2>Ingresos</h2><table><tr><th>Fecha</th><th>Hora</th><th>Estado</th><th>Periodo</th><th>Quién reporta</th></tr>{filas}</table></div>"))


@app.route("/excusas")
def excusas():
    if not requiere_login(): return redirect("/login")
    if rol_actual() not in ["Rectoría", "Coordinación", "Administrador", "Soporte"]: return acceso_denegado()
    filas = ''.join(f"<tr><td>{x.fecha}</td><td>{x.estudiante.codigo}</td><td>{x.estudiante.nombre} {x.estudiante.apellido}</td><td>{x.estudiante.grado}</td><td>{x.motivo}</td><td>{x.registrado_por}</td></tr>" for x in Excusa.query.order_by(Excusa.fecha.desc()).all())
    return page("Excusas", shell(f"<header class='header'><div class='header-info'><img src='/static/img/logo-colegio.png'><div><h1>Excusas</h1><p>Registro institucional.</p></div></div></header><div class='table-card'><table><tr><th>Fecha</th><th>Código</th><th>Nombre</th><th>Grado</th><th>Motivo</th><th>Registró</th></tr>{filas}</table></div>"))



@app.route("/alertas")
def alertas():
    if not requiere_login(): return redirect("/login")
    if not puede_alertas(): return acceso_denegado()

    grado = request.args.get("grado", "").strip()
    periodo = request.args.get("periodo", periodo_actual()).strip()

    estudiantes_q = Estudiante.query
    if grado:
        estudiantes_q = estudiantes_q.filter_by(grado=grado)

    opciones_grado = '<option value="">TODOS LOS GRADOS</option>' + ''.join(
        f'<option value="{g}" {"selected" if grado == g else ""}>{g}</option>' for g in grados_disponibles()
    )
    opciones_periodo = ''.join(
        f'<option value="{p}" {"selected" if periodo == p else ""}>{p}</option>' for p in ["Periodo 1", "Periodo 2", "Periodo 3"]
    )

    filas = ""
    amarillas = rojas = ausentes = 0
    for e in estudiantes_q.order_by(Estudiante.grado.asc(), Estudiante.nombre.asc()).all():
        ingresos = IngresoPorteria.query.filter_by(estudiante_id=e.id, periodo=periodo).all()
        aula = AsistenciaClase.query.filter_by(estudiante_id=e.id, periodo=periodo).all()
        tardes = sum(1 for i in ingresos if i.estado == "Tarde") + sum(1 for a in aula if a.estado == "Tarde")
        faltas = sum(1 for i in ingresos if i.estado == "No llegó") + sum(1 for a in aula if a.estado == "Ausente")
        if tardes == 1:
            amarillas += 1
            filas += f"<tr><td>{e.codigo}</td><td>{e.nombre} {e.apellido}</td><td>{e.grado}</td><td><span class='estado estado-tarde'>1 llegada tarde</span></td><td>Seguimiento preventivo</td></tr>"
        elif tardes >= 2:
            rojas += 1
            filas += f"<tr><td>{e.codigo}</td><td>{e.nombre} {e.apellido}</td><td>{e.grado}</td><td><span class='estado estado-no'>{tardes} llegadas tarde</span></td><td>Requiere intervención de Coordinación</td></tr>"
        if faltas >= 1:
            ausentes += 1
            filas += f"<tr><td>{e.codigo}</td><td>{e.nombre} {e.apellido}</td><td>{e.grado}</td><td><span class='estado estado-no'>{faltas} ausencia/no llegó</span></td><td>Validar excusa o contactar acudiente</td></tr>"

    content = f"""
<header class='header'>
  <div class='header-info'><img src='/static/img/logo-colegio.png'><div><h1>Alertas de asistencia</h1><p>1 llegada tarde = amarillo. 2 o más llegadas tarde = alerta fuerte.</p></div></div>
</header>

<div class='role-cards'>
  <div class='role-card yellow'><h3>{amarillas}</h3><p>Preventivas</p></div>
  <div class='role-card red'><h3>{rojas}</h3><p>Críticas por tardanza</p></div>
  <div class='role-card red'><h3>{ausentes}</h3><p>Ausencias/no llegó</p></div>
</div>

<section class='table-card'>
  <form method='GET' class='filter-bar'>
    <div class='form-row'>
      <div><label><b>Grado</b></label><select name='grado'>{opciones_grado}</select></div>
      <div><label><b>Periodo</b></label><select name='periodo'>{opciones_periodo}</select></div>
    </div>
    <button>Consultar alertas</button>
  </form>
  <table>
    <tr><th>Código</th><th>Nombre</th><th>Grado</th><th>Alerta</th><th>Acción recomendada</th></tr>
    {filas if filas else '<tr><td colspan="5">No hay alertas para estos filtros.</td></tr>'}
  </table>
</section>
"""
    return page("Alertas", shell(content))



def tipo_novedad_label(tipo):
    return {
        "llegada_tarde": "Justificación llegada tarde",
        "excusa": "Excusa por inasistencia",
        "salida_anticipada": "Salida anticipada",
        "citacion": "Citación acudiente",
    }.get(tipo, tipo)


def badge_novedad(tipo):
    clase = "badge-tarde"
    if tipo == "excusa": clase = "badge-excusa"
    if tipo == "salida_anticipada": clase = "badge-salida"
    if tipo == "citacion": clase = "badge-citacion"
    return f"<span class='novedad-badge {clase}'>{tipo_novedad_label(tipo)}</span>"


def guardar_archivo_excusa(file):
    if not file or not getattr(file, 'filename', ''):
        return ""
    nombre = re.sub(r"[^A-Za-z0-9_.-]", "_", file.filename)
    seguro = f"{fecha_hoy()}_{random.randint(1000,9999)}_{nombre}"
    ruta = os.path.join(UPLOAD_DIR, seguro)
    try:
        file.save(ruta)
        return ruta.replace("\\", "/")
    except Exception as e:
        print("ARCHIVO EXCUSA:", e)
        return ""


@app.route("/panel_convivencia")
def panel_convivencia():
    if not requiere_login(): return redirect("/login")
    if not puede_novedades(): return acceso_denegado()
    abiertas = Novedad.query.filter(Novedad.estado != "Cerrada").count()
    citaciones = Citacion.query.count()
    salidas = Novedad.query.filter_by(tipo="salida_anticipada", fecha=fecha_hoy()).count()
    ultimas = Novedad.query.order_by(Novedad.fecha.desc(), Novedad.hora.desc()).limit(12).all()
    filas = ''.join(f"<tr><td>{n.fecha}</td><td>{n.hora}</td><td>{n.estudiante.grado}</td><td>{estudiante_nombre(n.estudiante)}</td><td>{badge_novedad(n.tipo)}</td><td>{n.motivo}</td><td>{n.registrado_por}</td></tr>" for n in ultimas)
    content = f"""
<header class='role-hero'><div><h1>Panel de Convivencia</h1><p>Control de novedades, citaciones, excusas y salidas anticipadas.</p></div><div class='top-actions'><a class='btn' href='/historial_novedades'>Historial</a><a class='btn' href='/citaciones'>Citaciones</a></div></header>
<section class='conv-grid'>
  <div class='conv-card orange'><h2>{abiertas}</h2><p>Novedades abiertas</p></div>
  <div class='conv-card red'><h2>{citaciones}</h2><p>Citaciones generadas</p></div>
  <div class='conv-card green'><h2>{salidas}</h2><p>Salidas anticipadas hoy</p></div>
</section>
<section class='role-grid'>
  <div class='role-panel'><h2>Registrar novedad</h2><p>Justificar tardanzas, radicar excusas o autorizar salida anticipada.</p><a class='btn' href='/nueva_novedad'>Nueva novedad</a></div>
  <div class='role-panel'><h2>Generar citación</h2><p>Formato institucional en PDF y Word con logo, encabezado, firmas y observaciones editables.</p><a class='btn btn-green' href='/crear_citacion'>Crear citación</a></div>
</section>
<div class='table-card'><h2>Últimas novedades</h2><table><tr><th>Fecha</th><th>Hora</th><th>Grado</th><th>Estudiante</th><th>Tipo</th><th>Motivo</th><th>Registró</th></tr>{filas if filas else '<tr><td colspan="7">Sin novedades registradas.</td></tr>'}</table></div>
"""
    return page("Panel de Convivencia", shell(content))


@app.route("/historial_novedades")
def historial_novedades():
    if not requiere_login(): return redirect("/login")
    if not puede_novedades(): return acceso_denegado()
    q = request.args.get("q", "").strip()
    grado = request.args.get("grado", "").strip()
    tipo = request.args.get("tipo", "").strip()
    desde = request.args.get("desde", "").strip()
    hasta = request.args.get("hasta", "").strip()
    consulta = Novedad.query.join(Estudiante)
    if q:
        like = f"%{q.lower()}%"
        consulta = consulta.filter(or_(func.lower(Estudiante.nombre).like(like), func.lower(Estudiante.apellido).like(like), Estudiante.codigo.like(f"%{q}%"), Estudiante.documento.like(f"%{q}%")))
    if grado: consulta = consulta.filter(Estudiante.grado == grado)
    if tipo: consulta = consulta.filter(Novedad.tipo == tipo)
    if desde: consulta = consulta.filter(Novedad.fecha >= desde)
    if hasta: consulta = consulta.filter(Novedad.fecha <= hasta)
    novedades = consulta.order_by(Novedad.fecha.desc(), Novedad.hora.desc()).limit(200).all()
    opciones_grado = '<option value="">Todos</option>' + ''.join(f'<option value="{g}" {"selected" if grado==g else ""}>{g}</option>' for g in grados_disponibles())
    opciones_tipo = ''.join(f'<option value="{v}" {"selected" if tipo==v else ""}>{t}</option>' for v,t in [("","Todas"),("llegada_tarde","Llegada tarde"),("excusa","Excusa"),("salida_anticipada","Salida anticipada"),("citacion","Citación")])
    filas = ''.join(f"<tr><td>{n.fecha}</td><td>{n.hora}</td><td>{n.estudiante.codigo}</td><td>{estudiante_nombre(n.estudiante)}<br><span class='mini-text'>Doc: {n.estudiante.documento or 'Sin documento'}</span></td><td>{n.estudiante.grado}</td><td>{badge_novedad(n.tipo)}</td><td>{n.motivo}</td><td>{n.observacion}</td><td>{n.registrado_por}</td></tr>" for n in novedades)
    content = f"""
<header class='role-hero'><div><h1>Historial de Novedades</h1><p>Bitácora digital de llegadas tarde, excusas, salidas anticipadas y citaciones.</p></div><div class='top-actions'><a class='btn' href='/nueva_novedad'>Nueva novedad</a><a class='btn' href='/crear_citacion'>Nueva citación</a></div></header>
<section class='filter-bar'><form method='GET'><div class='form-row'><div><label><b>Buscar estudiante</b></label><input name='q' value='{q}' placeholder='Nombre, documento o código'></div><div><label><b>Grado</b></label><select name='grado'>{opciones_grado}</select></div></div><div class='form-row'><div><label><b>Tipo</b></label><select name='tipo'>{opciones_tipo}</select></div><div><label><b>Desde / Hasta</b></label><div class='form-row'><input type='date' name='desde' value='{desde}'><input type='date' name='hasta' value='{hasta}'></div></div></div><button>Consultar</button> <a class='btn btn-green' href='/exportar_novedades_excel?q={q}&grado={grado}&tipo={tipo}&desde={desde}&hasta={hasta}'>Excel institucional</a> <a class='btn' href='/exportar_novedades_pdf?q={q}&grado={grado}&tipo={tipo}&desde={desde}&hasta={hasta}'>PDF institucional</a> <a class='btn' href='/exportar_novedades_word?q={q}&grado={grado}&tipo={tipo}&desde={desde}&hasta={hasta}'>Word institucional</a></form></section>
<div class='table-card'><table><tr><th>Fecha</th><th>Hora</th><th>Código</th><th>Estudiante</th><th>Grado</th><th>Tipo</th><th>Motivo</th><th>Observación</th><th>Registró</th></tr>{filas if filas else '<tr><td colspan="9">No hay novedades para los filtros seleccionados.</td></tr>'}</table></div>
"""
    return page("Historial de Novedades", shell(content))


@app.route("/nueva_novedad", methods=["GET", "POST"])
def nueva_novedad():
    if not requiere_login(): return redirect("/login")
    if not puede_gestionar_novedades(): return acceso_denegado()
    mensaje = ""
    if request.method == "POST":
        estudiante = buscar_estudiante_por_codigo_doc_nombre(request.form.get("estudiante"))
        if not estudiante:
            mensaje = "No se encontró estudiante con ese dato."
        else:
            tipo = request.form.get("tipo")
            motivo = request.form.get("motivo", "").strip()
            observacion = request.form.get("observacion", "").strip()
            archivo = guardar_archivo_excusa(request.files.get("archivo")) if "archivo" in request.files else ""
            acudiente = request.form.get("acudiente_autoriza", "").strip()
            n = Novedad(estudiante_id=estudiante.id, tipo=tipo, motivo=motivo, observacion=observacion, archivo=archivo, acudiente_autoriza=acudiente, fecha=fecha_hoy(), hora=hora_actual(), periodo=periodo_actual(), registrado_por=f"{session.get('usuario')} ({rol_actual()})")
            db.session.add(n)
            if tipo == "llegada_tarde":
                ingreso = IngresoPorteria.query.filter_by(estudiante_id=estudiante.id, fecha=fecha_hoy()).order_by(IngresoPorteria.id.desc()).first()
                if ingreso and ingreso.estado == "Tarde":
                    ingreso.estado = "Tarde Justificado"
                    ingreso.registrado_por = f"{ingreso.registrado_por} / Justificado por {session.get('usuario')}"
            elif tipo == "excusa":
                db.session.add(Excusa(estudiante_id=estudiante.id, fecha=fecha_hoy(), motivo=observacion or motivo or "Excusa radicada", registrado_por=session.get("usuario", "Coordinación"), periodo=periodo_actual()))
            db.session.commit()
            registrar_auditoria("Nueva novedad", f"{tipo_novedad_label(tipo)} para {estudiante.codigo} - {estudiante_nombre(estudiante)}")
            return redirect("/historial_novedades")
    content = f"""
<header class='role-hero'><div><h1>Registrar novedad</h1><p>Justificación, excusa o salida anticipada.</p></div><a class='btn' href='/historial_novedades'>Volver</a></header>
<section class='role-panel'><form method='POST' enctype='multipart/form-data'>
<label><b>Estudiante</b></label><input name='estudiante' placeholder='Código, documento o nombre completo' required>
<label><b>Tipo de novedad</b></label><select name='tipo'><option value='llegada_tarde'>Justificación de llegada tarde</option><option value='excusa'>Radicación de excusa por inasistencia</option><option value='salida_anticipada'>Salida anticipada autorizada</option></select>
<label><b>Motivo</b></label><select name='motivo'><option>Transporte</option><option>Cita médica</option><option>Calamidad doméstica</option><option>Sin justificar</option><option>Autorización acudiente</option><option>Otro</option></select>
<label><b>Acudiente que autoriza / reporta</b></label><input name='acudiente_autoriza' placeholder='Nombre del acudiente, si aplica'>
<label><b>Observaciones</b></label><textarea name='observacion' rows='5' placeholder='Detalle de la novedad'></textarea>
<label><b>Soporte de excusa</b></label><input type='file' name='archivo' accept='image/*,.pdf,.doc,.docx'><p class='field-help'>Puedes tomar foto de la excusa o subir PDF. En Render free el almacenamiento no es permanente; para producción se recomienda almacenamiento externo.</p>
<button>Guardar novedad</button>{'<div class="msg danger">'+mensaje+'</div>' if mensaje else ''}
</form></section>
"""
    return page("Nueva novedad", shell(content))


@app.route("/citaciones")
def citaciones():
    if not requiere_login(): return redirect("/login")
    if not puede_citaciones(): return acceso_denegado()
    q = request.args.get("q", "").strip()
    grado = request.args.get("grado", "").strip()
    consulta = Citacion.query.join(Estudiante)
    if q:
        like = f"%{q.lower()}%"
        consulta = consulta.filter(or_(func.lower(Estudiante.nombre).like(like), func.lower(Estudiante.apellido).like(like), Estudiante.codigo.like(f"%{q}%"), Estudiante.documento.like(f"%{q}%")))
    if grado: consulta = consulta.filter(Estudiante.grado == grado)
    citas = consulta.order_by(Citacion.fecha_creacion.desc(), Citacion.hora_creacion.desc()).limit(150).all()
    opciones_grado = '<option value="">Todos</option>' + ''.join(f'<option value="{g}" {"selected" if grado==g else ""}>{g}</option>' for g in grados_disponibles())
    filas = ''.join(f"<tr><td>{c.fecha_creacion}</td><td>{c.fecha_citacion} {c.hora_citacion}</td><td>{c.estudiante.codigo}</td><td>{estudiante_nombre(c.estudiante)}</td><td>{c.estudiante.grado}</td><td>{c.acudiente}</td><td>{c.motivo}</td><td><a href='/citacion_pdf/{c.id}'>PDF</a> · <a href='/citacion_word/{c.id}'>Word</a></td></tr>" for c in citas)
    content = f"""
<header class='role-hero'><div><h1>Citaciones a padres de familia</h1><p>Formatos institucionales descargables en PDF y Word.</p></div><a class='btn' href='/crear_citacion'>Crear citación</a></header>
<section class='filter-bar'><form method='GET'><div class='form-row'><input name='q' value='{q}' placeholder='Nombre, documento o código'><select name='grado'>{opciones_grado}</select></div><button>Consultar</button></form></section>
<div class='table-card'><table><tr><th>Creación</th><th>Citación</th><th>Código</th><th>Estudiante</th><th>Grado</th><th>Acudiente</th><th>Motivo</th><th>Descargar</th></tr>{filas if filas else '<tr><td colspan="8">No hay citaciones.</td></tr>'}</table></div>
"""
    return page("Citaciones", shell(content))


@app.route("/crear_citacion", methods=["GET", "POST"])
def crear_citacion():
    if not requiere_login(): return redirect("/login")
    if not puede_gestionar_novedades(): return acceso_denegado()
    mensaje = ""
    estudiante = None
    estudiante_id = request.args.get("estudiante_id")
    if estudiante_id:
        estudiante = Estudiante.query.get(estudiante_id)
    if request.method == "POST":
        estudiante = buscar_estudiante_por_codigo_doc_nombre(request.form.get("estudiante"))
        if not estudiante:
            mensaje = "No se encontró estudiante."
        else:
            fecha_cit = request.form.get("fecha_citacion") or fecha_hoy()
            hora_cit = request.form.get("hora_citacion", "").strip()
            motivo = request.form.get("motivo", "Llegadas tarde").strip()
            obs = request.form.get("observaciones", "").strip()
            acud = request.form.get("acudiente", "").strip() or estudiante.acudiente or estudiante.madre or estudiante.padre
            c = Citacion(estudiante_id=estudiante.id, fecha_creacion=fecha_hoy(), hora_creacion=hora_actual(), fecha_citacion=fecha_cit, hora_citacion=hora_cit, motivo=motivo, observaciones=obs, acudiente=acud, generado_por=f"{session.get('usuario')} ({rol_actual()})", periodo=periodo_actual())
            db.session.add(c); db.session.flush()
            db.session.add(Novedad(estudiante_id=estudiante.id, tipo="citacion", motivo=motivo, observacion=f"Citación para {fecha_cit} {hora_cit}. {obs}", fecha=fecha_hoy(), hora=hora_actual(), periodo=periodo_actual(), registrado_por=f"{session.get('usuario')} ({rol_actual()})"))
            db.session.commit()
            registrar_auditoria("Generar citación", f"Citación {c.id} para {estudiante.codigo} - {estudiante_nombre(estudiante)}")
            return redirect(f"/citaciones")
    valor_est = f"{estudiante.codigo}" if estudiante else ""
    content = f"""
<header class='role-hero'><div><h1>Crear citación</h1><p>Formato institucional para padres de familia y estudiantes.</p></div><a class='btn' href='/citaciones'>Volver</a></header>
<section class='role-panel'><form method='POST'>
<label><b>Estudiante</b></label><input name='estudiante' value='{valor_est}' placeholder='Código, documento o nombre completo' required>
<div class='form-row'><div><label><b>Fecha de citación</b></label><input type='date' name='fecha_citacion' required></div><div><label><b>Hora</b></label><input name='hora_citacion' placeholder='Ej: 10:30 a. m.'></div></div>
<label><b>Padre/madre/acudiente</b></label><input name='acudiente' placeholder='Se puede dejar vacío para usar el acudiente registrado'>
<label><b>Motivo</b></label><input name='motivo' value='Llegadas tarde'>
<label><b>Observaciones</b></label><textarea name='observaciones' rows='6'>De acuerdo con el registro digital y log de auditoría del sistema EduTrack QR, el estudiante presenta novedades de asistencia que requieren acompañamiento institucional.</textarea>
<button>Generar citación</button>{'<div class="msg danger">'+mensaje+'</div>' if mensaje else ''}
</form></section>
"""
    return page("Crear citación", shell(content))


def texto_citacion(c):
    e = c.estudiante
    hora = f" a las {c.hora_citacion}" if c.hora_citacion else ""
    return f"El coordinador de la I.E. Gabriel Correa Vélez le solicita presentarse con su hijo(a) a la institución educativa sede principal, el próximo {c.fecha_citacion}{hora}, con el fin de tratar asuntos relacionados con su hijo(a)."


def nombre_archivo_citacion(c, ext):
    limpio = re.sub(r"[^A-Za-z0-9]+", "_", estudiante_nombre(c.estudiante)).strip("_").lower()
    return f"citacion_{limpio}.{ext}"


@app.route("/citacion_pdf/<int:id>")
def citacion_pdf(id):
    if not requiere_login(): return redirect("/login")
    if not puede_citaciones(): return acceso_denegado()
    c = Citacion.query.get_or_404(id); e = c.estudiante
    b = BytesIO(); pdf = canvas.Canvas(b, pagesize=letter); pdf.setTitle(f"Citacion de {estudiante_nombre(e)}")
    width, height = letter; y = height - 45
    try: pdf.drawImage("static/img/logo-colegio.png", 45, y-55, width=55, height=55, preserveAspectRatio=True, mask='auto')
    except Exception: pass
    pdf.setFont("Helvetica-Bold", 10); pdf.drawString(115, y, INST_NOMBRE); y -= 13
    pdf.setFont("Helvetica", 8); pdf.drawString(115, y, f"Sede {INST_SEDE} · DANE {INST_DANE} · NIT {INST_NIT}"); y -= 13
    pdf.drawString(115, y, INST_DIRECCION); y -= 26
    pdf.setFont("Helvetica-Bold", 11); pdf.drawCentredString(width/2, y, "CITACIÓN A PADRES DE FAMILIA Y ESTUDIANTE"); y -= 28
    styles = getSampleStyleSheet(); body = ParagraphStyle('body', parent=styles['BodyText'], fontName='Helvetica', fontSize=9, leading=12)
    p = Paragraph(texto_citacion(c), body); w,h = p.wrap(width-90, 80); p.drawOn(pdf,45,y-h); y -= h + 18
    data = [["ESTUDIANTE", Paragraph(estudiante_nombre(e), body)], ["GRADO", e.grado], ["ACUDIENTE", Paragraph(c.acudiente or e.acudiente or e.madre or e.padre or "", body)], ["MOTIVO", Paragraph(c.motivo or "", body)], ["OBSERVACIONES", Paragraph((c.observaciones or "").replace("\n","<br/>"), body)]]
    tabla = Table(data, colWidths=[120, 385])
    tabla.setStyle(TableStyle([('GRID',(0,0),(-1,-1),0.8,colors.black),('BACKGROUND',(0,0),(0,-1),colors.lightgrey),('FONTNAME',(0,0),(0,-1),'Helvetica-Bold'),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]))
    tw, th = tabla.wrap(width-90, y-160); tabla.drawOn(pdf,45,y-th); y -= th + 36
    pdf.setFont("Helvetica", 9); pdf.drawString(45, y, "Atentamente,"); y -= 42
    pdf.line(45,y,230,y); y -= 13; pdf.setFont("Helvetica-Bold", 8); pdf.drawString(45,y,"Coordinador I.E. Gabriel Correa Vélez"); y -= 36
    pdf.line(45,y,230,y); pdf.drawString(45,y-13,"Firma acudiente"); pdf.line(310,y,495,y); pdf.drawString(310,y-13,"Firma estudiante")
    pdf.setFont("Helvetica", 7); pdf.drawCentredString(width/2, 25, f"Generado por {APP_NAME} · {fecha_hoy()} {hora_actual()}")
    pdf.save(); b.seek(0)
    return send_file(b, as_attachment=True, download_name=nombre_archivo_citacion(c, "pdf"), mimetype="application/pdf")


@app.route("/citacion_word/<int:id>")
def citacion_word(id):
    if not requiere_login(): return redirect("/login")
    if not puede_citaciones(): return acceso_denegado()
    c = Citacion.query.get_or_404(id); e = c.estudiante
    doc = Document()
    try:
        doc.add_picture("static/img/logo-colegio.png", width=Inches(0.8))
    except Exception: pass
    h = doc.add_paragraph(); h.add_run(INST_NOMBRE).bold = True
    doc.add_paragraph(f"Sede {INST_SEDE} · DANE {INST_DANE} · NIT {INST_NIT}")
    doc.add_paragraph(INST_DIRECCION)
    doc.add_heading("CITACIÓN A PADRES DE FAMILIA Y ESTUDIANTE", level=1)
    doc.add_paragraph(f"Señor padre/madre de familia o acudiente: {c.acudiente or e.acudiente or e.madre or e.padre or ''}")
    doc.add_paragraph(texto_citacion(c))
    t = doc.add_table(rows=5, cols=2); t.style = "Table Grid"
    rows = [("ESTUDIANTE", estudiante_nombre(e)), ("GRADO", e.grado), ("ACUDIENTE", c.acudiente or e.acudiente or e.madre or e.padre or ""), ("MOTIVO", c.motivo or ""), ("OBSERVACIONES", c.observaciones or "")]
    for i,(a,bv) in enumerate(rows):
        t.rows[i].cells[0].text = a; t.rows[i].cells[1].text = bv
        for run in t.rows[i].cells[0].paragraphs[0].runs: run.bold = True
    doc.add_paragraph("\nAtentamente,\n")
    doc.add_paragraph("_____________________________\nCoordinador I.E. Gabriel Correa Vélez")
    doc.add_paragraph("\n_____________________________\nFirma acudiente")
    doc.add_paragraph("\n_____________________________\nFirma estudiante")
    doc.add_paragraph(f"\nGenerado por {APP_NAME} · {fecha_hoy()} {hora_actual()}")
    b = BytesIO(); doc.save(b); b.seek(0)
    return send_file(b, as_attachment=True, download_name=nombre_archivo_citacion(c, "docx"), mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")


@app.route("/historial_estudiante_novedades/<int:id>")
def historial_estudiante_novedades(id):
    if not requiere_login(): return redirect("/login")
    if not puede_novedades(): return acceso_denegado()
    e = Estudiante.query.get_or_404(id)
    ingresos = IngresoPorteria.query.filter_by(estudiante_id=e.id).order_by(IngresoPorteria.fecha.desc(), IngresoPorteria.hora.desc()).limit(50).all()
    novedades = Novedad.query.filter_by(estudiante_id=e.id).order_by(Novedad.fecha.desc(), Novedad.hora.desc()).all()
    cit = Citacion.query.filter_by(estudiante_id=e.id).order_by(Citacion.fecha_creacion.desc()).all()
    filas_i = ''.join(f"<tr><td>{i.fecha}</td><td>{i.hora}</td><td>{estado_badge(i.estado)}</td><td>{i.periodo}</td><td>{i.registrado_por}</td></tr>" for i in ingresos)
    filas_n = ''.join(f"<tr><td>{n.fecha}</td><td>{n.hora}</td><td>{badge_novedad(n.tipo)}</td><td>{n.motivo}</td><td>{n.observacion}</td><td>{n.registrado_por}</td></tr>" for n in novedades)
    filas_c = ''.join(f"<tr><td>{c.fecha_creacion}</td><td>{c.fecha_citacion}</td><td>{c.motivo}</td><td>{c.acudiente}</td><td><a href='/citacion_pdf/{c.id}'>PDF</a> · <a href='/citacion_word/{c.id}'>Word</a></td></tr>" for c in cit)
    content = f"""
<header class='role-hero'><div><h1>Historial integral del estudiante</h1><p>{estudiante_nombre(e)} · Grado {e.grado} · Código {e.codigo}</p></div><div class='top-actions'><a class='btn' href='/nueva_novedad'>Nueva novedad</a><a class='btn' href='/crear_citacion?estudiante_id={e.id}'>Citación</a></div></header>
<section class='role-grid'><div class='role-panel'><h2>Datos</h2><p><b>Documento:</b> {e.documento or 'Sin documento'}</p><p><b>Acudiente:</b> {e.acudiente or e.madre or e.padre}</p><p><b>Teléfono:</b> {e.telefono_acudiente}</p><p><b>Dirección:</b> {e.direccion}</p></div><div class='role-panel'><h2>Acciones</h2><a class='btn' href='/crear_citacion?estudiante_id={e.id}'>Generar citación</a> <a class='btn' href='/nueva_novedad'>Registrar novedad</a></div></section>
<div class='table-card'><h2>Ingresos</h2><table><tr><th>Fecha</th><th>Hora</th><th>Estado</th><th>Periodo</th><th>Quién reporta</th></tr>{filas_i if filas_i else '<tr><td colspan="5">Sin ingresos.</td></tr>'}</table></div>
<div class='table-card'><h2>Novedades</h2><table><tr><th>Fecha</th><th>Hora</th><th>Tipo</th><th>Motivo</th><th>Observación</th><th>Registró</th></tr>{filas_n if filas_n else '<tr><td colspan="6">Sin novedades.</td></tr>'}</table></div>
<div class='table-card'><h2>Citaciones</h2><table><tr><th>Creación</th><th>Fecha citación</th><th>Motivo</th><th>Acudiente</th><th>Documentos</th></tr>{filas_c if filas_c else '<tr><td colspan="5">Sin citaciones.</td></tr>'}</table></div>
"""
    return page("Historial estudiante", shell(content))

@app.route("/contacto")
def contacto():
    return page("Contacto", shell(f"""<header class="header"><div class="header-info"><img src="/static/img/logo-colegio.png"><div><h1>Contacto Institucional</h1><p>Soporte y acompañamiento técnico.</p></div></div></header><section class="card"><div class="contact-grid"><div class="contact-card"><div class="contact-icon">☎</div><h3>DESARROLLADOR PRINCIPAL</h3><p><b>Sebastián López</b><br>Soporte técnico EduTrack QR</p><p>📞 <a href="tel:{SOPORTE_TELEFONO}">{SOPORTE_TELEFONO}</a></p><p>✉️ <a href="mailto:{SOPORTE_EMAIL}">{SOPORTE_EMAIL}</a></p></div><div class="contact-card"><div class="contact-icon">✉</div><h3>SOPORTE TECNOLÓGICO</h3><p>Plataforma EduTrack QR</p><p>✉️ <a href="mailto:{SOPORTE_EMAIL}">{SOPORTE_EMAIL}</a></p></div><div class="contact-card"><div class="contact-icon">💼</div><h3>CARTERA Y FACTURACIÓN</h3><p>📞 <a href="tel:{CARTERA_TELEFONO}">{CARTERA_TELEFONO}</a></p><p>✉️ <a href="mailto:{CARTERA_EMAIL}">{CARTERA_EMAIL}</a></p></div></div><div class="slogan-box"><h2>{APP_NAME}</h2><p>{SLOGAN}</p></div></section>"""))


@app.route("/configuracion", methods=["GET", "POST"])
def configuracion():
    if not requiere_login(): return redirect("/login")
    if not puede_configurar(): return acceso_denegado()
    cfg = config()
    mensaje = ""
    if request.method == "POST":
        cfg.periodo_actual = request.form.get("periodo_actual", cfg.periodo_actual)
        cfg.jornada = request.form.get("jornada", cfg.jornada)
        if rol_actual() in ["Administrador", "Soporte"]:
            cfg.modo_mantenimiento = request.form.get("modo_mantenimiento") == "on"
            cfg.mensaje_mantenimiento = request.form.get("mensaje_mantenimiento", cfg.mensaje_mantenimiento)
        db.session.commit()
        registrar_auditoria("Configuración", f"Actualizó periodo/jornada desde panel de configuración: {cfg.periodo_actual} - {cfg.jornada}")
        mensaje = "Configuración guardada correctamente."
    mantenimiento = ""
    if rol_actual() in ["Administrador", "Soporte"]:
        mantenimiento = f"""<label><input type='checkbox' name='modo_mantenimiento' style='width:auto' {'checked' if cfg.modo_mantenimiento else ''}> Activar modo mantenimiento</label><input name='mensaje_mantenimiento' value='{cfg.mensaje_mantenimiento}' placeholder='Mensaje de mantenimiento'>"""
    content = f"""
<header class='role-hero'><div><h1>Periodo y jornada</h1><p>Rectoría puede cambiar el periodo académico y la jornada activa.</p></div><a class='btn' href='/dashboard'>Volver</a></header>
{'<div class="msg ok">'+mensaje+'</div>' if mensaje else ''}
<section class='role-panel'>
<form method='POST'>
<label>Periodo actual</label>
<select name='periodo_actual'>
<option {'selected' if periodo_actual()=='Periodo 1' else ''}>Periodo 1</option>
<option {'selected' if periodo_actual()=='Periodo 2' else ''}>Periodo 2</option>
<option {'selected' if periodo_actual()=='Periodo 3' else ''}>Periodo 3</option>
</select>
<label>Jornada</label>
<select name='jornada'>
<option {'selected' if jornada_actual()=='Mañana' else ''}>Mañana</option>
<option {'selected' if jornada_actual()=='Tarde' else ''}>Tarde</option>
<option {'selected' if jornada_actual()=='Única' else ''}>Única</option>
</select>
{mantenimiento}
<button>Guardar configuración</button>
</form>
</section>
"""
    return page("Configuración", shell(content))


@app.route("/soporte-login", methods=["GET", "POST"])
def soporte_login():
    error = ""
    if request.method == "POST":
        u = login_usuario(request.form.get("usuario"), request.form.get("password"), "Soporte")
        if u:
            session["usuario"] = u.usuario; session["rol"] = u.rol; return redirect("/soporte")
        error = "Acceso incorrecto."
    return page("Soporte", f"<div class='center'><section class='card login-card'><h1>Soporte</h1><p class='error'>{error}</p><form method='POST'><input name='usuario' placeholder='Usuario'><input name='password' type='password' placeholder='Contraseña'><button>Ingresar</button></form><a href='/login'>Volver</a></section></div>")


@app.route("/soporte")
def soporte():
    if not requiere_login() or rol_actual() not in ["Soporte", "Administrador"]: return redirect("/soporte-login")
    return page("Soporte", shell(f"<header class='header'><div class='header-info'><img src='/static/img/logo-colegio.png'><div><h1>Panel de Soporte</h1><p>Estado técnico del sistema.</p></div></div></header><section class='table-card'><h2>Estado</h2><p>Usuarios: {Usuario.query.count()}</p><p>Estudiantes: {Estudiante.query.count()}</p><p>Ingresos: {IngresoPorteria.query.count()}</p></section>"))



@app.route("/auditoria", methods=["GET", "POST"])
def auditoria():
    if not requiere_login(): return redirect("/login")
    if not puede_auditoria(): return acceso_denegado()
    mensaje = ""
    if request.method == "POST":
        if rol_actual() not in ["Soporte", "Administrador"]:
            return acceso_denegado("Solo soporte técnico puede limpiar auditoría.")
        codigo = request.form.get("codigo_seguridad", "")
        if verificar_codigo_auditoria(codigo):
            Auditoria.query.delete()
            db.session.commit()
            registrar_auditoria("Limpieza auditoría", "Soporte limpió el historial de auditoría con código de seguridad")
            mensaje = "Auditoría limpiada correctamente."
        else:
            registrar_auditoria("Intento limpieza auditoría", "Código de seguridad incorrecto")
            mensaje = "Código de seguridad incorrecto."
    eventos = Auditoria.query.order_by(Auditoria.id.desc()).limit(300).all()
    filas = ''.join(f"<tr class='audit-row'><td>{a.fecha}</td><td>{a.hora}</td><td>{a.usuario}</td><td>{a.rol}</td><td>{a.accion}</td><td>{a.detalle}</td><td>{a.ip}</td></tr>" for a in eventos)
    limpiar = ""
    if rol_actual() in ["Soporte", "Administrador"]:
        limpiar = """<section class='role-panel'><h2>Limpiar auditoría</h2><p class='role-muted'>Solo soporte puede limpiar este historial. En entrega final configura AUDITORIA_DELETE_HASH en Render.</p><form method='POST'><input name='codigo_seguridad' type='password' placeholder='Código secreto de auditoría' required><button class='btn-red'>Eliminar auditoría</button></form></section><br>"""
    content = f"""<header class='role-hero'><div><h1>Auditoría del sistema</h1><p>Registro de actividad para saber quién hizo qué y cuándo.</p></div><a class='btn' href='/dashboard'>Volver</a></header>{'<div class="msg ok">'+mensaje+'</div>' if mensaje and 'correctamente' in mensaje else ''}{'<div class="msg danger">'+mensaje+'</div>' if mensaje and 'incorrecto' in mensaje else ''}{limpiar}<div class='table-card'><table><tr><th>Fecha</th><th>Hora</th><th>Usuario</th><th>Rol</th><th>Acción</th><th>Detalle</th><th>IP</th></tr>{filas}</table></div>"""
    return page("Auditoría", shell(content))


@app.route("/backup")
def backup():
    if not requiere_login(): return redirect("/login")
    if not puede_admin(): return acceso_denegado()
    wb = Workbook()
    ws = wb.active; ws.title = "Estudiantes"
    ws.append(["codigo", "nombre", "apellido", "grado", "director"])
    for e in Estudiante.query.order_by(Estudiante.grado.asc(), Estudiante.nombre.asc()).all(): ws.append([e.codigo, e.nombre, e.apellido, e.grado, e.director])
    ws2 = wb.create_sheet("Ingresos")
    ws2.append(["codigo", "estudiante", "grado", "fecha", "hora", "estado", "periodo", "registrado_por"])
    for i in IngresoPorteria.query.join(Estudiante).order_by(IngresoPorteria.id.desc()).all(): ws2.append([i.estudiante.codigo, f"{i.estudiante.nombre} {i.estudiante.apellido}", i.estudiante.grado, i.fecha, i.hora, i.estado, i.periodo, i.registrado_por])
    ws3 = wb.create_sheet("Usuarios")
    ws3.append(["usuario", "rol", "correo", "grupo_docente"])
    for u in Usuario.query.order_by(Usuario.rol.asc()).all(): ws3.append([u.usuario, u.rol, u.correo, u.grupo_docente])
    registrar_auditoria("Backup", "Descargó copia de seguridad en Excel")
    b = BytesIO(); wb.save(b); b.seek(0)
    return send_file(b, as_attachment=True, download_name=f"backup_edutrack_{fecha_hoy()}.xlsx")


def datos_reporte():
    data = []
    for i in IngresoPorteria.query.join(Estudiante).order_by(Estudiante.grado.asc(), IngresoPorteria.fecha.desc()).all():
        data.append([i.estudiante.codigo, f"{i.estudiante.nombre} {i.estudiante.apellido}", i.estudiante.grado, i.estudiante.director, i.fecha, i.hora, i.registrado_por])
    return data


@app.route("/reportes")
def reportes():
    if not requiere_login(): return redirect("/login")
    if not puede_reportes(): return acceso_denegado()
    filas = ''.join(f"<tr><td>{r[0]}</td><td>{r[1]}</td><td>{r[2]}</td><td>{r[3]}</td><td>{r[4]}</td><td>{r[5]}</td><td>{r[6]}</td></tr>" for r in datos_reporte())
    content = f"<header class='header'><div class='header-info'><img src='/static/img/logo-colegio.png'><div><h1>Reportes institucionales</h1><p>Formato tipo planilla.</p></div></div><div><a class='btn' href='/exportar_excel_reportes'>Excel</a> <a class='btn' href='/exportar_pdf'>PDF</a> <a class='btn' href='/exportar_word'>Word</a></div></header><div class='table-card'><table><tr><th>Código</th><th>Nombre y apellido</th><th>Grado</th><th>Director</th><th>Fecha</th><th>Hora</th><th>Quién reporta</th></tr>{filas}</table></div>"
    return page("Reportes", shell(content))


def encabezado(): return [INST_NOMBRE, f"SEDE {INST_SEDE}", INST_RESOLUCION, f"DANE: {INST_DANE} | NIT: {INST_NIT}", f"Dirección: {INST_DIRECCION}", f"Fecha de impresión: {ahora().strftime('%Y-%m-%d %H:%M:%S')}"]


def estilo_excel(ws, header_row):
    amarillo = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid"); borde = Border(left=Side(style="thin"), right=Side(style="thin"), top=Side(style="thin"), bottom=Side(style="thin"))
    for row in ws.iter_rows():
        for cell in row:
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True); cell.border = borde
    for cell in ws[header_row]: cell.fill = amarillo; cell.font = Font(bold=True)
    for col, width in {"A":16,"B":32,"C":12,"D":26,"E":16,"F":14,"G":22}.items(): ws.column_dimensions[col].width = width


@app.route("/exportar_estudiantes")
def exportar_estudiantes():
    if not requiere_login(): return redirect("/login")
    if not puede_estudiantes(): return acceso_denegado()
    wb = Workbook(); ws = wb.active
    for l in encabezado(): ws.append([l])
    ws.append([]); header_row = ws.max_row + 1; ws.append(["CÓDIGO", "NOMBRE", "APELLIDO", "DOCUMENTO", "GRADO", "DIRECTOR", "RH", "ACUDIENTE", "PADRE", "MADRE", "TELÉFONO ACUDIENTE", "CORREO ACUDIENTE", "DIRECCIÓN", "OBSERVACIÓN"])
    for e in Estudiante.query.order_by(Estudiante.grado.asc(), Estudiante.nombre.asc()).all(): ws.append([e.codigo, e.nombre, e.apellido, getattr(e,'documento',''), e.grado, e.director, getattr(e,'rh',''), getattr(e,'acudiente',''), getattr(e,'padre',''), getattr(e,'madre',''), getattr(e,'telefono_acudiente',''), getattr(e,'correo_acudiente',''), getattr(e,'direccion',''), getattr(e,'observacion','')])
    estilo_excel(ws, header_row); b = BytesIO(); wb.save(b); b.seek(0); return send_file(b, as_attachment=True, download_name="estudiantes_edutrack.xlsx")


@app.route("/exportar_excel_reportes")
def exportar_excel():
    if not requiere_login(): return redirect("/login")
    if not puede_reportes(): return acceso_denegado()
    wb = Workbook(); ws = wb.active
    for l in encabezado(): ws.append([l])
    ws.append([]); header_row = ws.max_row + 1; ws.append(["CÓDIGO", "NOMBRE Y APELLIDO", "GRADO", "DIRECTOR DE GRUPO", "FECHA", "HORA", "QUIÉN REPORTA"])
    for r in datos_reporte(): ws.append(r)
    estilo_excel(ws, header_row); b = BytesIO(); wb.save(b); b.seek(0); return send_file(b, as_attachment=True, download_name="reporte_ingresos_edutrack.xlsx")


@app.route("/exportar_pdf")
def exportar_pdf():
    if not requiere_login(): return redirect("/login")
    if not puede_reportes(): return acceso_denegado()
    b = BytesIO(); pdf = canvas.Canvas(b, pagesize=landscape(letter)); width, height = landscape(letter); y = height - 45
    try: pdf.drawImage("static/img/logo-colegio.png", 70, y - 65, width=65, height=65, preserveAspectRatio=True)
    except Exception: pass
    pdf.setFont("Helvetica-Bold", 14); pdf.drawCentredString(width / 2, y, INST_NOMBRE); y -= 17; pdf.setFont("Helvetica", 9)
    for linea in encabezado()[1:]: pdf.drawCentredString(width / 2, y, linea); y -= 13
    y -= 20; pdf.setFont("Helvetica-Bold", 12); pdf.drawString(40, y, "REPORTE DE INGRESOS"); y -= 22
    data = [["CÓDIGO", "NOMBRE Y APELLIDO", "GRADO", "DIRECTOR DE GRUPO", "FECHA", "HORA", "QUIÉN REPORTA"]] + datos_reporte()
    table = Table(data, colWidths=[70, 160, 60, 140, 80, 70, 120]); table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.yellow),("GRID", (0, 0), (-1, -1), 0.7, colors.black),("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),("ALIGN", (0, 0), (-1, -1), "CENTER"),("FONTSIZE", (0, 0), (-1, -1), 8)])); table.wrapOn(pdf, width, height); table.drawOn(pdf, 40, max(80, y - (len(data) * 22)))
    pdf.setFont("Helvetica", 8); pdf.drawCentredString(width / 2, 25, f"{APP_NAME} © 2026 | {SLOGAN} | Desarrollado por {DESARROLLADOR}"); pdf.save(); b.seek(0); return send_file(b, as_attachment=True, download_name="reporte_ingresos_edutrack.pdf")


@app.route("/exportar_word")
def exportar_word():
    if not requiere_login(): return redirect("/login")
    if not puede_reportes(): return acceso_denegado()
    doc = Document(); doc.add_paragraph("\n".join(encabezado())); doc.add_heading("REPORTE DE INGRESOS", level=1); t = doc.add_table(rows=1, cols=7); t.style = "Table Grid"; headers = ["CÓDIGO", "NOMBRE Y APELLIDO", "GRADO", "DIRECTOR DE GRUPO", "FECHA", "HORA", "QUIÉN REPORTA"]
    for i, h in enumerate(headers): t.rows[0].cells[i].text = h
    for r in datos_reporte():
        cells = t.add_row().cells
        for i, v in enumerate(r): cells[i].text = str(v)
    doc.add_paragraph(f"{APP_NAME} © 2026 | {SLOGAN}"); doc.add_paragraph(f"Desarrollado por {DESARROLLADOR}"); b = BytesIO(); doc.save(b); b.seek(0); return send_file(b, as_attachment=True, download_name="reporte_ingresos_edutrack.docx")




def reporte_padres_data(grupo="TODOS", desde="", hasta="", solo_tarde=False):
    q = IngresoPorteria.query.join(Estudiante)
    if grupo and grupo != "TODOS": q = q.filter(Estudiante.grado == grupo)
    if desde: q = q.filter(IngresoPorteria.fecha >= desde)
    if hasta: q = q.filter(IngresoPorteria.fecha <= hasta)
    if solo_tarde: q = q.filter(IngresoPorteria.estado == "Tarde")
    return q.order_by(Estudiante.grado.asc(), Estudiante.apellido.asc(), IngresoPorteria.fecha.desc(), IngresoPorteria.hora.desc()).all()


@app.route("/ficha_estudiante/<int:id>")
def ficha_estudiante(id):
    if not requiere_login(): return redirect("/login")
    if not puede_ver_historial(): return acceso_denegado()
    e = Estudiante.query.get_or_404(id)
    ingresos = IngresoPorteria.query.filter_by(estudiante_id=e.id).order_by(IngresoPorteria.fecha.desc(), IngresoPorteria.hora.desc()).limit(30).all()
    filas = ''.join(f"<tr><td>{i.fecha}</td><td>{i.hora}</td><td>{estado_badge(i.estado)}</td><td>{i.periodo}</td><td>{i.registrado_por}</td></tr>" for i in ingresos)
    content = f"""
<header class='role-hero'><div><h1>Ficha del estudiante</h1><p>Información completa, familiar e historial reciente.</p></div><a class='btn' href='/estudiantes'>Volver</a></header>
<section class='role-grid'>
  <div class='role-panel'><h2>{e.nombre} {e.apellido}</h2><p><b>Código:</b> {e.codigo}</p><p><b>Documento:</b> {getattr(e,'documento','')}</p><p><b>Grado:</b> {e.grado}</p><p><b>Director:</b> {e.director}</p><p><b>RH:</b> {getattr(e,'rh','')}</p></div>
  <div class='role-panel'><h2>Datos acudiente</h2><p><b>Acudiente:</b> {getattr(e,'acudiente','')}</p><p><b>Padre:</b> {getattr(e,'padre','')}</p><p><b>Madre:</b> {getattr(e,'madre','')}</p><p><b>Teléfono:</b> {getattr(e,'telefono_acudiente','')}</p><p><b>Correo:</b> {getattr(e,'correo_acudiente','')}</p><p><b>Dirección:</b> {getattr(e,'direccion','')}</p></div>
</section>
<section class='table-card'><h2>Historial reciente</h2><table><tr><th>Fecha</th><th>Hora</th><th>Estado</th><th>Periodo</th><th>Registró</th></tr>{filas}</table></section>
"""
    return page("Ficha estudiante", shell(content))


@app.route("/importar_estudiantes", methods=["GET", "POST"])
def importar_estudiantes():
    if not requiere_login(): return redirect("/login")
    if not puede_estudiantes(): return acceso_denegado()
    mensaje = ""
    if request.method == "POST":
        archivo = request.files.get("archivo")
        if not archivo or not archivo.filename.lower().endswith(".xlsx"):
            mensaje = "Sube un archivo Excel .xlsx válido."
        else:
            wb = load_workbook(archivo, data_only=True)
            ws = wb.active
            headers = [str(c.value or "").strip().lower() for c in ws[1]]
            def val(row, names):
                for name in names:
                    if name in headers:
                        v = row[headers.index(name)].value
                        return str(v).strip() if v is not None else ""
                return ""
            creados = actualizados = saltados = 0
            for row in ws.iter_rows(min_row=2):
                codigo = val(row, ["codigo", "código", "cod"])
                if not codigo:
                    saltados += 1; continue
                e = Estudiante.query.filter_by(codigo=codigo).first()
                if not e:
                    e = Estudiante(codigo=codigo); db.session.add(e); creados += 1
                else:
                    actualizados += 1
                e.nombre = val(row, ["nombre", "nombres"]) or e.nombre or "Sin nombre"
                e.apellido = val(row, ["apellido", "apellidos"]) or e.apellido or "Sin apellido"
                e.grado = val(row, ["grado", "grupo"]) or e.grado or "11"
                e.director = val(row, ["director", "director de grupo"]) or e.director or "Sin asignar"
                e.documento = val(row, ["documento", "dni", "tarjeta", "ti"])
                e.rh = val(row, ["rh", "sangre"])
                e.acudiente = val(row, ["acudiente", "acudiente principal"])
                e.padre = val(row, ["padre"])
                e.madre = val(row, ["madre"])
                e.telefono_acudiente = val(row, ["telefono", "teléfono", "telefono acudiente", "teléfono acudiente", "celular"])
                e.correo_acudiente = val(row, ["correo", "email", "correo acudiente"])
                e.direccion = val(row, ["direccion", "dirección"])
                e.observacion = val(row, ["observacion", "observación"])
            db.session.commit()
            registrar_auditoria("Importar estudiantes Excel", f"Creados {creados}, actualizados {actualizados}, saltados {saltados}")
            mensaje = f"Importación terminada. Creados: {creados}. Actualizados: {actualizados}. Saltados: {saltados}."
    content = f"""
<header class='role-hero'><div><h1>Importar estudiantes desde Excel</h1><p>Sube estudiantes por grupo sin registrarlos uno por uno.</p></div><a class='btn' href='/estudiantes'>Volver</a></header>
<div class='role-panel'>
  {'<div class="msg ok">'+mensaje+'</div>' if mensaje and 'terminada' in mensaje else ''}
  {'<div class="msg danger">'+mensaje+'</div>' if mensaje and 'terminada' not in mensaje else ''}
  <form method='POST' enctype='multipart/form-data'>
    <input type='file' name='archivo' accept='.xlsx' required>
    <button>Subir e importar</button>
  </form>
  <div class='security-note'>Columnas aceptadas: codigo, nombre, apellido, documento, grado, director, rh, acudiente, padre, madre, telefono, correo, direccion, observacion.</div>
</div>
"""
    return page("Importar Excel", shell(content))


@app.route("/reportes_padres")
def reportes_padres():
    if not requiere_login(): return redirect("/login")
    if not puede_reportes_padres(): return acceso_denegado()
    grupo = request.args.get("grupo", "TODOS")
    desde = request.args.get("desde", fecha_hoy())
    hasta = request.args.get("hasta", fecha_hoy())
    solo = request.args.get("solo", "tarde")
    solo_tarde = solo == "tarde"
    registros = reporte_padres_data(grupo, desde, hasta, solo_tarde)
    opciones = '<option value="TODOS">TODOS</option>' + ''.join(f'<option value="{g}" {"selected" if grupo==g else ""}>{g}</option>' for g in grados_disponibles())
    filas = ''.join(f"<tr><td>{i.estudiante.grado}</td><td>{i.estudiante.nombre} {i.estudiante.apellido}</td><td>{getattr(i.estudiante,'acudiente','')}</td><td>{getattr(i.estudiante,'telefono_acudiente','')}</td><td>{i.fecha}</td><td>{i.hora}</td><td>{estado_badge(i.estado)}</td></tr>" for i in registros)
    content = f"""
<header class='role-hero'><div><h1>Reportes para padres de familia</h1><p>Reporte por grupo, pensado para informar llegadas tarde e inasistencias.</p></div><a class='btn' href='/dashboard'>Volver</a></header>
<div class='notice-box'>Notificación: este reporte no muestra todo mezclado; filtra por grupo y rango de fecha para entregar información clara a acudientes o directivos.</div>
<form class='filter-bar' method='GET'>
  <div class='form-row'><select name='grupo'>{opciones}</select><input type='date' name='desde' value='{desde}'></div>
  <div class='form-row'><input type='date' name='hasta' value='{hasta}'><select name='solo'><option value='tarde' {'selected' if solo=='tarde' else ''}>Solo llegadas tarde</option><option value='todos' {'selected' if solo=='todos' else ''}>Todos los estados</option></select></div>
  <button>Consultar</button> <a class='btn btn-green' href='/exportar_reporte_padres_excel?grupo={grupo}&desde={desde}&hasta={hasta}&solo={solo}'>Excel</a> <a class='btn' href='/exportar_reporte_padres_pdf?grupo={grupo}&desde={desde}&hasta={hasta}&solo={solo}'>PDF</a>
</form>
<section class='table-card'><h2>Grupo: {grupo} · Registros: {len(registros)}</h2><table><tr><th>Grupo</th><th>Estudiante</th><th>Acudiente</th><th>Teléfono</th><th>Fecha</th><th>Hora</th><th>Estado</th></tr>{filas}</table></section>
"""
    return page("Reportes padres", shell(content))


@app.route("/exportar_reporte_padres_excel")
def exportar_reporte_padres_excel():
    if not requiere_login(): return redirect("/login")
    if not puede_reportes_padres(): return acceso_denegado()
    grupo = request.args.get("grupo", "TODOS"); desde = request.args.get("desde", ""); hasta = request.args.get("hasta", ""); solo = request.args.get("solo", "tarde")
    regs = reporte_padres_data(grupo, desde, hasta, solo == "tarde")
    wb = Workbook(); ws = wb.active; ws.title = "Reporte padres"
    for l in encabezado(): ws.append([l])
    ws.append([f"REPORTE PADRES - GRUPO {grupo} - {desde} a {hasta}"])
    ws.append([]); header_row = ws.max_row + 1
    ws.append(["GRUPO", "CÓDIGO", "ESTUDIANTE", "ACUDIENTE", "TELÉFONO", "CORREO", "FECHA", "HORA", "ESTADO"])
    for i in regs:
        e = i.estudiante
        ws.append([e.grado, e.codigo, f"{e.nombre} {e.apellido}", getattr(e,'acudiente',''), getattr(e,'telefono_acudiente',''), getattr(e,'correo_acudiente',''), i.fecha, i.hora, i.estado])
    estilo_excel(ws, header_row)
    b = BytesIO(); wb.save(b); b.seek(0)
    return send_file(b, as_attachment=True, download_name=f"reporte_padres_{grupo}_{desde}_{hasta}.xlsx")


@app.route("/exportar_reporte_padres_pdf")
def exportar_reporte_padres_pdf():
    if not requiere_login(): return redirect("/login")
    if not puede_reportes_padres(): return acceso_denegado()
    grupo = request.args.get("grupo", "TODOS"); desde = request.args.get("desde", ""); hasta = request.args.get("hasta", ""); solo = request.args.get("solo", "tarde")
    regs = reporte_padres_data(grupo, desde, hasta, solo == "tarde")
    b = BytesIO(); pdf = canvas.Canvas(b, pagesize=landscape(letter)); width, height = landscape(letter); y = height - 45
    try: pdf.drawImage("static/img/logo-colegio.png", 45, y - 50, width=55, height=55, preserveAspectRatio=True)
    except Exception: pass
    pdf.setFont("Helvetica-Bold", 13); pdf.drawCentredString(width/2, y, INST_NOMBRE); y -= 16
    pdf.setFont("Helvetica", 9); pdf.drawCentredString(width/2, y, f"Reporte para padres de familia · Grupo {grupo} · {desde} a {hasta}"); y -= 28
    data = [["GRUPO", "ESTUDIANTE", "ACUDIENTE", "TELÉFONO", "FECHA", "HORA", "ESTADO"]]
    for i in regs:
        e = i.estudiante
        data.append([e.grado, f"{e.nombre} {e.apellido}", getattr(e,'acudiente',''), getattr(e,'telefono_acudiente',''), i.fecha, i.hora, i.estado])
    table = Table(data, colWidths=[50,160,145,100,80,70,80])
    table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.yellow),("GRID",(0,0),(-1,-1),0.5,colors.black),("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,-1),8),("ALIGN",(0,0),(-1,-1),"CENTER")]))
    table.wrapOn(pdf,width,height); table.drawOn(pdf,40,max(80,y-(len(data)*20)))
    pdf.setFont("Helvetica",8); pdf.drawCentredString(width/2,25,f"{APP_NAME} · {SLOGAN}")
    pdf.save(); b.seek(0)
    return send_file(b, as_attachment=True, download_name=f"reporte_padres_{grupo}_{desde}_{hasta}.pdf")


# ==============================
# FASE 14 - DESCARGAS INSTITUCIONALES PROFESIONALES
# ==============================
def consulta_novedades_filtrada(q="", grado="", tipo="", desde="", hasta=""):
    consulta = Novedad.query.join(Estudiante)
    q = (q or "").strip()
    grado = (grado or "").strip()
    tipo = (tipo or "").strip()
    desde = (desde or "").strip()
    hasta = (hasta or "").strip()
    if q:
        like = f"%{q.lower()}%"
        consulta = consulta.filter(or_(func.lower(Estudiante.nombre).like(like), func.lower(Estudiante.apellido).like(like), Estudiante.codigo.like(f"%{q}%"), Estudiante.documento.like(f"%{q}%")))
    if grado:
        consulta = consulta.filter(Estudiante.grado == grado)
    if tipo:
        consulta = consulta.filter(Novedad.tipo == tipo)
    if desde:
        consulta = consulta.filter(Novedad.fecha >= desde)
    if hasta:
        consulta = consulta.filter(Novedad.fecha <= hasta)
    return consulta.order_by(Novedad.fecha.desc(), Novedad.hora.desc()).limit(500).all()


def titulo_reporte_novedades(grado="", tipo=""):
    partes = ["HISTORIAL DE NOVEDADES"]
    if grado:
        partes.append(f"GRADO {grado}")
    if tipo:
        partes.append(tipo.replace("_", " ").upper())
    return " - ".join(partes)


def nombre_archivo_novedades(ext, grado=""):
    g = f"_grado_{grado}" if grado else ""
    return f"historial_novedades{g}_{fecha_hoy()}.{ext}"


@app.route("/exportar_novedades_excel")
def exportar_novedades_excel():
    if not requiere_login(): return redirect("/login")
    if not puede_novedades(): return acceso_denegado()
    q = request.args.get("q", "")
    grado = request.args.get("grado", "")
    tipo = request.args.get("tipo", "")
    desde = request.args.get("desde", "")
    hasta = request.args.get("hasta", "")
    novedades = consulta_novedades_filtrada(q, grado, tipo, desde, hasta)
    wb = Workbook(); ws = wb.active; ws.title = "Novedades"
    ws.merge_cells("A1:I1"); ws["A1"] = INST_NOMBRE; ws["A1"].font = Font(bold=True, size=14, color="FFFFFF"); ws["A1"].fill = PatternFill("solid", fgColor="0B2D57"); ws["A1"].alignment = Alignment(horizontal="center")
    ws.merge_cells("A2:I2"); ws["A2"] = f"Sede {INST_SEDE} · DANE {INST_DANE} · NIT {INST_NIT}"
    ws.merge_cells("A3:I3"); ws["A3"] = INST_DIRECCION
    ws.merge_cells("A4:I4"); ws["A4"] = titulo_reporte_novedades(grado, tipo); ws["A4"].font = Font(bold=True, size=12); ws["A4"].fill = PatternFill("solid", fgColor="D9EAF7")
    ws.merge_cells("A5:I5"); ws["A5"] = f"Periodo: {periodo_actual()} · Jornada: {jornada_actual()} · Generado: {fecha_hoy()} {hora_actual()} · Usuario: {session.get('usuario')}"
    ws.append([])
    header = ["FECHA", "HORA", "CÓDIGO", "DOCUMENTO", "ESTUDIANTE", "GRADO", "TIPO", "MOTIVO", "OBSERVACIÓN / REGISTRÓ"]
    ws.append(header); header_row = ws.max_row
    for n in novedades:
        ws.append([n.fecha, n.hora, n.estudiante.codigo, n.estudiante.documento or "", estudiante_nombre(n.estudiante), n.estudiante.grado, n.tipo.replace("_", " ").title(), n.motivo or "", f"{n.observacion or ''}\nRegistró: {n.registrado_por or ''}"])
    fill_head = PatternFill("solid", fgColor="0B2D57")
    fill_alt = PatternFill("solid", fgColor="F3F6FA")
    border = Border(left=Side(style="thin"), right=Side(style="thin"), top=Side(style="thin"), bottom=Side(style="thin"))
    for cell in ws[header_row]:
        cell.font = Font(bold=True, color="FFFFFF"); cell.fill = fill_head; cell.alignment = Alignment(horizontal="center", vertical="center")
    for row in ws.iter_rows(min_row=header_row+1):
        for cell in row:
            cell.border = border; cell.alignment = Alignment(vertical="top", wrap_text=True)
        if row[0].row % 2 == 0:
            for cell in row: cell.fill = fill_alt
    for col, width in {"A":13,"B":12,"C":14,"D":16,"E":30,"F":10,"G":20,"H":28,"I":55}.items(): ws.column_dimensions[col].width = width
    ws.freeze_panes = f"A{header_row+1}"
    b = BytesIO(); wb.save(b); b.seek(0)
    return send_file(b, as_attachment=True, download_name=nombre_archivo_novedades("xlsx", grado), mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/exportar_novedades_pdf")
def exportar_novedades_pdf():
    if not requiere_login(): return redirect("/login")
    if not puede_novedades(): return acceso_denegado()
    q = request.args.get("q", "")
    grado = request.args.get("grado", "")
    tipo = request.args.get("tipo", "")
    desde = request.args.get("desde", "")
    hasta = request.args.get("hasta", "")
    novedades = consulta_novedades_filtrada(q, grado, tipo, desde, hasta)
    b = BytesIO(); pdf = canvas.Canvas(b, pagesize=landscape(letter)); pdf.setTitle(titulo_reporte_novedades(grado, tipo))
    width, height = landscape(letter); y = height - 45
    try: pdf.drawImage("static/img/logo-colegio.png", 45, y-55, width=55, height=55, preserveAspectRatio=True, mask='auto')
    except Exception: pass
    pdf.setFont("Helvetica-Bold", 13); pdf.drawString(115, y, INST_NOMBRE); y -= 14
    pdf.setFont("Helvetica", 8); pdf.drawString(115, y, f"Sede {INST_SEDE} · DANE {INST_DANE} · NIT {INST_NIT}"); y -= 12
    pdf.drawString(115, y, INST_DIRECCION); y -= 20
    pdf.setFont("Helvetica-Bold", 12); pdf.drawCentredString(width/2, y, titulo_reporte_novedades(grado, tipo)); y -= 20
    pdf.setFont("Helvetica", 8); pdf.drawCentredString(width/2, y, f"Periodo: {periodo_actual()} · Generado: {fecha_hoy()} {hora_actual()} · Usuario: {session.get('usuario')}"); y -= 16
    styles = getSampleStyleSheet(); small = ParagraphStyle('smallNovedad', parent=styles['BodyText'], fontName='Helvetica', fontSize=7, leading=8)
    data = [["FECHA", "HORA", "CÓDIGO", "ESTUDIANTE", "GRADO", "TIPO", "MOTIVO", "OBSERVACIÓN"]]
    for n in novedades[:80]:
        data.append([n.fecha, n.hora, n.estudiante.codigo, Paragraph(estudiante_nombre(n.estudiante), small), n.estudiante.grado, n.tipo.replace("_", " ").title(), Paragraph(n.motivo or "", small), Paragraph((n.observacion or "").replace("\n", "<br/>"), small)])
    table = Table(data, colWidths=[58,50,65,120,45,85,115,215])
    table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#0B2D57')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('GRID',(0,0),(-1,-1),0.4,colors.grey),('VALIGN',(0,0),(-1,-1),'TOP'),('FONTSIZE',(0,0),(-1,-1),7),('LEFTPADDING',(0,0),(-1,-1),4),('RIGHTPADDING',(0,0),(-1,-1),4),('TOPPADDING',(0,0),(-1,-1),4),('BOTTOMPADDING',(0,0),(-1,-1),4)]))
    tw, th = table.wrap(width-80, y-60); table.drawOn(pdf,40,max(60,y-th))
    pdf.setFont("Helvetica", 7); pdf.drawCentredString(width/2, 25, f"{APP_NAME} · {SLOGAN} · Desarrollado por {DESARROLLADOR}")
    pdf.save(); b.seek(0)
    return send_file(b, as_attachment=True, download_name=nombre_archivo_novedades("pdf", grado), mimetype="application/pdf")


@app.route("/exportar_novedades_word")
def exportar_novedades_word():
    if not requiere_login(): return redirect("/login")
    if not puede_novedades(): return acceso_denegado()
    q = request.args.get("q", "")
    grado = request.args.get("grado", "")
    tipo = request.args.get("tipo", "")
    desde = request.args.get("desde", "")
    hasta = request.args.get("hasta", "")
    novedades = consulta_novedades_filtrada(q, grado, tipo, desde, hasta)
    doc = Document()
    try: doc.add_picture("static/img/logo-colegio.png", width=Inches(0.75))
    except Exception: pass
    p = doc.add_paragraph(); r = p.add_run(INST_NOMBRE); r.bold = True; r.font.size = Pt(13)
    doc.add_paragraph(f"Sede {INST_SEDE} · DANE {INST_DANE} · NIT {INST_NIT}")
    doc.add_paragraph(INST_DIRECCION)
    doc.add_heading(titulo_reporte_novedades(grado, tipo), level=1)
    doc.add_paragraph(f"Periodo: {periodo_actual()} · Jornada: {jornada_actual()} · Generado: {fecha_hoy()} {hora_actual()} · Usuario: {session.get('usuario')}")
    table = doc.add_table(rows=1, cols=8); table.style = "Table Grid"
    headers = ["Fecha", "Hora", "Código", "Estudiante", "Grado", "Tipo", "Motivo", "Observación / Registró"]
    for i,h in enumerate(headers):
        table.rows[0].cells[i].text = h
        for run in table.rows[0].cells[i].paragraphs[0].runs: run.bold = True
    for n in novedades[:200]:
        row = table.add_row().cells
        vals = [n.fecha, n.hora, n.estudiante.codigo, estudiante_nombre(n.estudiante), n.estudiante.grado, n.tipo.replace("_", " ").title(), n.motivo or "", f"{n.observacion or ''}\nRegistró: {n.registrado_por or ''}"]
        for i,v in enumerate(vals): row[i].text = str(v)
    doc.add_paragraph(f"\n{APP_NAME} · {SLOGAN}\nDesarrollado por {DESARROLLADOR}")
    b = BytesIO(); doc.save(b); b.seek(0)
    return send_file(b, as_attachment=True, download_name=nombre_archivo_novedades("docx", grado), mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")

@app.route("/legal")
def legal(): return page("Legal", f"<div class='center'><section class='card'><h1>Aviso legal</h1><p>{APP_NAME} desarrollado por {DESARROLLADOR}.</p><a href='/login'>Volver</a></section></div>")


@app.route("/cookies")
def cookies(): return page("Cookies", "<div class='center'><section class='card'><h1>Cookies</h1><p>Se usan cookies técnicas de sesión.</p><a href='/login'>Volver</a></section></div>")


@app.route("/logout")
def logout():
    if requiere_login(): registrar_auditoria("Cierre de sesión", f"Usuario {session.get('usuario')} salió")
    session.clear(); return redirect("/login")


if __name__ == "__main__":
    with app.app_context(): inicializar_bd()
    app.run(debug=True, host="0.0.0.0")
